export type UserRole = 'citizen' | 'admin' | 'guest';

export interface AppUser {
  id: string;
  email: string;
  role: UserRole;
  displayName?: string;
  state?: string;
  createdAt: string;
}
