export type SchemeCategory =
  | 'education'
  | 'agriculture'
  | 'housing'
  | 'employment'
  | 'financial_assistance'
  | 'senior_citizens'
  | 'disability_support'
  | 'women_and_child';

export type VerificationStatus = 'verified' | 'needs_review' | 'expired';

export type MatchTier = 'strong' | 'possible' | 'general';

export interface Scheme {
  id: string;
  name: string;
  name_hi?: string;
  name_as?: string;
  slug: string;
  description: string;
  description_hi?: string;
  description_as?: string;
  department: string;
  category: SchemeCategory;
  state: string; // 'All India' or specific state name e.g. 'Assam', 'Uttar Pradesh'
  min_age?: number;
  max_age?: number;
  gender_eligibility?: 'all' | 'female_only' | 'male_only' | 'transgender_inclusive';
  income_limit?: number; // Maximum annual household income in INR
  income_category?: 'all' | 'bpl_antyodaya' | 'below_1_lakh' | 'below_2_5_lakh' | 'below_5_lakh' | 'below_8_lakh';
  occupations?: string[]; // e.g. ['student', 'farmer', 'artisan', 'daily_wage', 'unemployed', 'self_employed', 'all']
  student_requirement?: 'not_required' | 'pre_matric' | 'post_matric' | 'higher_education' | 'vocational' | 'any_student';
  farmer_requirement?: 'not_required' | 'marginal_small' | 'all_farmers' | 'tenant_farmer';
  disability_requirement?: boolean; // requires disability
  min_disability_percent?: number;
  caste_category?: ('all' | 'sc' | 'st' | 'obc' | 'general' | 'minority')[];
  area_type?: 'all' | 'rural' | 'urban';
  other_criteria?: string[];
  benefits: string;
  benefits_hi?: string;
  benefits_as?: string;
  benefits_amount?: string; // e.g. "₹6,000 / year" or "Up to ₹5,00,000 health cover"
  documents: string[];
  documents_hi?: string[];
  documents_as?: string[];
  application_steps: string[];
  application_steps_hi?: string[];
  application_steps_as?: string[];
  official_url: string;
  source_url: string;
  last_verified: string; // ISO date format YYYY-MM-DD
  verification_status: VerificationStatus;
  is_demo_data?: boolean; // Flag to indicate if it's a demonstration record
  tags?: string[];
  created_at?: string;
  updated_at?: string;
}

export interface MatchReason {
  matched: boolean;
  criterion: string;
  description: string;
  weight: number;
}

export interface SchemeMatchResult {
  scheme: Scheme;
  matchScore: number; // 0 to 100
  tier: MatchTier;
  reasons: MatchReason[];
  isEligibleCandidate: boolean;
}

export interface SavedScheme {
  id: string;
  user_id?: string;
  scheme_id: string;
  scheme?: Scheme;
  created_at: string;
  reminder_date?: string;
  reminder_note?: string;
  reminder_completed?: boolean;
}
