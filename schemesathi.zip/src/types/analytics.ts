export type AnalyticsEventType =
  | 'questionnaire_started'
  | 'questionnaire_completed'
  | 'scheme_viewed'
  | 'official_link_clicked'
  | 'scheme_saved'
  | 'voice_search_used'
  | 'simple_mode_toggled'
  | 'language_changed';

export interface AnalyticsEvent {
  id?: string;
  event_type: AnalyticsEventType;
  event_data?: Record<string, unknown>;
  created_at?: string;
}

export interface AnalyticsSummary {
  totalQuestionnairesCompleted: number;
  totalQuestionnairesStarted: number;
  totalOfficialLinksClicked: number;
  totalSchemesSaved: number;
  categoryViews: Record<string, number>;
  topSchemesViewed: { schemeId: string; schemeName: string; count: number }[];
  stateInteractions: Record<string, number>;
}
