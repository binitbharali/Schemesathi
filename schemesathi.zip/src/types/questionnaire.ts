export type Gender = 'male' | 'female' | 'transgender' | 'prefer_not_to_say';

export type OccupationType =
  | 'student'
  | 'farmer'
  | 'daily_wage_laborer'
  | 'artisan_craftsperson'
  | 'self_employed_small_business'
  | 'salaried_private'
  | 'government_employee'
  | 'unemployed'
  | 'homemaker'
  | 'retired_senior'
  | 'other';

export type IncomeBracket =
  | 'bpl_antyodaya'      // Below Poverty Line (< ~₹50,000/yr or holding Antyodaya/BPL card)
  | 'below_1_lakh'       // ₹50,000 - ₹1,00,000
  | '1_to_2_5_lakh'      // ₹1,00,000 - ₹2,50,000
  | '2_5_to_5_lakh'      // ₹2,50,000 - ₹5,00,000
  | '5_to_8_lakh'        // ₹5,00,000 - ₹8,00,000
  | 'above_8_lakh';      // > ₹8,00,000

export type StudentLevel =
  | 'not_applicable'
  | 'pre_matric'         // Class 1-10
  | 'post_matric'        // Class 11-12, Diploma
  | 'undergraduate'      // BA, BSc, BTech, etc.
  | 'postgraduate'       // MA, MSc, MTech, PhD
  | 'vocational_iti';    // ITI / Skill Development

export type FarmerCategory =
  | 'not_applicable'
  | 'marginal'           // Land < 1 hectare (2.5 acres)
  | 'small'              // Land 1 - 2 hectares (2.5 - 5 acres)
  | 'medium_large'       // Land > 2 hectares
  | 'tenant_landless';   // Landless agricultural laborer / Sharecropper

export type SocialCategory =
  | 'general'
  | 'sc'                 // Scheduled Caste
  | 'st'                 // Scheduled Tribe
  | 'obc'                // Other Backward Class
  | 'minority'           // Religious / Linguistic Minority
  | 'prefer_not_to_say';

export type AreaType = 'rural' | 'urban' | 'semi_urban';

export type HousingType = 'kutcha' | 'semi_pucca' | 'pucca' | 'homeless' | 'rented';

export interface QuestionnaireAnswers {
  // Step 1: Age & Gender
  age?: number;
  gender?: Gender;
  
  // Step 2: Location
  state: string;
  district?: string;
  areaType?: AreaType;

  // Step 3: Occupation
  occupation?: OccupationType;
  
  // Step 4: Household Income Range
  incomeBracket?: IncomeBracket;
  hasBplOrRationCard?: boolean;

  // Step 5: Specific Target Details
  studentLevel?: StudentLevel;
  farmerCategory?: FarmerCategory;
  isPregnantOrLactating?: boolean;
  isSingleWomanOrWidow?: boolean;

  // Step 6: Disability Status (Optional)
  hasDisability?: boolean;
  disabilityPercentage?: number;
  disabilityType?: string;

  // Step 7: Social Category & Housing
  socialCategory?: SocialCategory;
  housingType?: HousingType;
  isExServiceman?: boolean;
  isStreetVendorOrArtisan?: boolean;
}

export const INITIAL_QUESTIONNAIRE_ANSWERS: QuestionnaireAnswers = {
  age: 24,
  gender: 'male',
  state: 'All India',
  district: '',
  areaType: 'rural',
  occupation: 'student',
  incomeBracket: '1_to_2_5_lakh',
  hasBplOrRationCard: false,
  studentLevel: 'undergraduate',
  farmerCategory: 'not_applicable',
  isPregnantOrLactating: false,
  isSingleWomanOrWidow: false,
  hasDisability: false,
  socialCategory: 'general',
  housingType: 'pucca',
  isExServiceman: false,
  isStreetVendorOrArtisan: false,
};
