import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Search,
  Filter,
  ArrowRight,
  RefreshCw,
  Info,
  CheckCircle2,
  Bookmark,
  MapPin,
  Building2,
  Compass,
  FileQuestion,
  SlidersHorizontal,
  Bot
} from 'lucide-react';
import { Scheme, SchemeCategory, SchemeMatchResult } from './types/scheme';
import { QuestionnaireAnswers } from './types/questionnaire';
import { SchemeService } from './services/schemeService';
import { rankSchemesByEligibility } from './services/recommendationEngine';
import { AnalyticsService } from './services/analyticsService';

import { LanguageProvider, useLanguage } from './hooks/useLanguage';
import { SimpleModeProvider, useSimpleMode } from './hooks/useSimpleMode';
import { SavedSchemesProvider } from './hooks/useSavedSchemes';
import { AuthProvider, useAuth } from './hooks/useAuth';

import { DisclaimerBanner } from './components/layout/DisclaimerBanner';
import { DemoFlowBanner } from './components/layout/DemoFlowBanner';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';

import { Hero } from './components/landing/Hero';
import { HowItWorks } from './components/landing/HowItWorks';
import { CategoriesGrid } from './components/landing/CategoriesGrid';
import { WhySchemeSathi } from './components/landing/WhySchemeSathi';
import { VerificationHighlight } from './components/landing/VerificationHighlight';
import { FaqSection } from './components/landing/FaqSection';

import { QuestionnaireModal } from './components/questionnaire/QuestionnaireModal';
import { SchemeCard } from './components/schemes/SchemeCard';
import { SchemeDetailsModal } from './components/schemes/SchemeDetailsModal';
import { SchemeFilterBar } from './components/schemes/SchemeFilterBar';
import { SimpleModeView } from './components/simple/SimpleModeView';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { UserDashboard } from './components/dashboard/UserDashboard';
import { SchemeAssistantModal } from './components/ai/SchemeAssistantModal';

const SchemeSathiApp: React.FC = () => {
  const { t } = useLanguage();
  const { isSimpleMode, toggleSimpleMode } = useSimpleMode();
  const { isAdmin, loginAsAdmin } = useAuth();

  // App Navigation & Modal States
  const [currentView, setCurrentView] = useState<'home' | 'browse' | 'results' | 'saved' | 'reminders' | 'admin'>('home');
  const [isQuestionnaireOpen, setIsQuestionnaireOpen] = useState(false);
  const [isAssistantOpen, setIsAssistantOpen] = useState(false);
  const [selectedSchemeForDetails, setSelectedSchemeForDetails] = useState<Scheme | null>(null);

  // Scheme Data State
  const [schemes, setSchemes] = useState<Scheme[]>([]);
  const [loading, setLoading] = useState(true);

  // User Questionnaire State
  const [userAnswers, setUserAnswers] = useState<QuestionnaireAnswers | null>(null);
  const [rankedResults, setRankedResults] = useState<SchemeMatchResult[]>([]);
  const [activePresetName, setActivePresetName] = useState<string | null>(null);

  // Filtering State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<SchemeCategory | 'all'>('all');
  const [selectedState, setSelectedState] = useState('All India');
  const [selectedOccupation, setSelectedOccupation] = useState('all');

  // Load schemes from service
  const loadSchemes = async () => {
    setLoading(true);
    const data = await SchemeService.getAllSchemes();
    setSchemes(data);
    setLoading(false);
  };

  useEffect(() => {
    loadSchemes();
  }, []);

  // Update recommendations whenever answers or schemes update
  useEffect(() => {
    if (userAnswers && schemes.length > 0) {
      const ranked = rankSchemesByEligibility(schemes, userAnswers);
      setRankedResults(ranked);
    }
  }, [userAnswers, schemes]);

  // Handle questionnaire completion
  const handleQuestionnaireComplete = (answers: QuestionnaireAnswers) => {
    setUserAnswers(answers);
    const ranked = rankSchemesByEligibility(schemes, answers);
    setRankedResults(ranked);
    setCurrentView('results');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handle Preset Loader for SIH Evaluators
  const handleLoadPreset = (presetData: QuestionnaireAnswers, presetName: string) => {
    setActivePresetName(presetName);
    setUserAnswers(presetData);
    const ranked = rankSchemesByEligibility(schemes, presetData);
    setRankedResults(ranked);
    setCurrentView('results');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Filter schemes for browse view
  const filteredBrowseSchemes = schemes.filter((scheme) => {
    if (selectedCategory !== 'all' && scheme.category !== selectedCategory) {
      return false;
    }
    if (selectedState !== 'All India' && scheme.state !== 'All India' && scheme.state !== selectedState) {
      return false;
    }
    if (selectedOccupation !== 'all') {
      if (
        scheme.occupations &&
        scheme.occupations.length > 0 &&
        !scheme.occupations.includes('all') &&
        !scheme.occupations.includes(selectedOccupation)
      ) {
        return false;
      }
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = scheme.name.toLowerCase().includes(q);
      const matchDesc = scheme.description.toLowerCase().includes(q);
      const matchDept = scheme.department.toLowerCase().includes(q);
      const matchBen = scheme.benefits.toLowerCase().includes(q);
      if (!matchName && !matchDesc && !matchDept && !matchBen) {
        return false;
      }
    }
    return true;
  });

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedState('All India');
    setSelectedOccupation('all');
  };

  const handleSelectCategoryFromLanding = (cat: SchemeCategory) => {
    setSelectedCategory(cat);
    setCurrentView('browse');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigate = (view: 'home' | 'browse' | 'results' | 'saved' | 'reminders' | 'admin') => {
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className={`min-h-screen flex flex-col justify-between antialiased ${
      isSimpleMode ? 'bg-amber-50/30 text-slate-900' : 'bg-slate-50 text-slate-800 selection:bg-indigo-200 selection:text-indigo-900'
    }`}>
      <div>
        {/* SIH 2026 Evaluator Quick Test Preset Banner */}
        <DemoFlowBanner
          onLoadPreset={handleLoadPreset}
          onOpenAdmin={() => {
            loginAsAdmin();
            setCurrentView('admin');
          }}
          onOpenSimpleMode={toggleSimpleMode}
        />

        {/* Public Informational Disclaimer Bar */}
        <DisclaimerBanner />

        {/* Sticky Header Navigation */}
        <Navbar
          currentView={currentView}
          onNavigate={(view) => handleNavigate(view as any)}
          onOpenQuestionnaire={() => setIsQuestionnaireOpen(true)}
          onOpenAssistant={() => setIsAssistantOpen(true)}
        />

        {/* VIEW 1: HOME (Standard Landing or High-Accessibility Simple Mode) */}
        {currentView === 'home' && (
          isSimpleMode ? (
            <main>
              <SimpleModeView
                schemes={schemes}
                onViewDetails={(s) => setSelectedSchemeForDetails(s)}
                onOpenQuestionnaire={() => setIsQuestionnaireOpen(true)}
                onOpenAssistant={() => setIsAssistantOpen(true)}
                onNavigate={handleNavigate}
              />
            </main>
          ) : (
            <main>
              <Hero
                onOpenQuestionnaire={() => setIsQuestionnaireOpen(true)}
                onBrowseSchemes={() => handleNavigate('browse')}
              />
              <HowItWorks onOpenQuestionnaire={() => setIsQuestionnaireOpen(true)} />
              <CategoriesGrid onSelectCategory={handleSelectCategoryFromLanding} />
              <WhySchemeSathi />
              <VerificationHighlight />
              <FaqSection />
            </main>
          )
        )}

        {/* VIEW 2: QUESTIONNAIRE RESULTS PAGE */}
        {currentView === 'results' && (
          <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6 animate-in fade-in">
            {/* Results Header */}
            <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-3 py-1 rounded-full flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Rule-Engine Evaluation Complete</span>
                  </span>
                  {activePresetName && (
                    <span className="text-xs font-semibold bg-amber-400 text-slate-950 px-2.5 py-0.5 rounded-full">
                      Preset: {activePresetName}
                    </span>
                  )}
                </div>

                <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
                  {t.results.title}
                </h1>

                <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
                  {t.results.subtitle}
                </p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  id="re-run-questionnaire-btn"
                  onClick={() => setIsQuestionnaireOpen(true)}
                  className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs sm:text-sm border border-white/20 flex items-center gap-2 transition-colors"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>{t.results.edit_answers}</span>
                </button>
              </div>
            </div>

            {/* Profile Summary Badge Bar */}
            {userAnswers && (
              <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs flex flex-wrap items-center gap-2 text-xs font-medium text-slate-700">
                <span className="text-slate-400 font-bold uppercase text-[10px]">Your Profile:</span>
                <span className="px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200">
                  📍 {userAnswers.state} {userAnswers.district ? `(${userAnswers.district})` : ''}
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200 capitalize">
                  💼 {userAnswers.occupation.replace(/_/g, ' ')}
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200">
                  💰 {userAnswers.incomeBracket.replace(/_/g, ' ')}
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200 capitalize">
                  🎂 {userAnswers.age} yrs • {userAnswers.gender}
                </span>
                {userAnswers.hasDisability && (
                  <span className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-800 border border-blue-200">
                    ♿ Divyangjan Assistive Priority
                  </span>
                )}
              </div>
            )}

            {/* Matched Schemes Grid */}
            {rankedResults.length === 0 ? (
              <div className="bg-white rounded-3xl p-12 text-center space-y-4 border border-slate-200">
                <p className="text-base text-slate-600">
                  No matching schemes found for this exact criteria. Try adjusting your responses.
                </p>
                <button
                  onClick={() => setIsQuestionnaireOpen(true)}
                  className="px-5 py-2.5 rounded-xl bg-emerald-700 text-white font-bold text-xs"
                >
                  Modify Questionnaire
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between text-xs text-slate-500 font-semibold">
                  <span>Showing {rankedResults.length} ranked scheme matches (sorted by qualification strength)</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {rankedResults.map((result) => (
                    <SchemeCard
                      key={result.scheme.id}
                      scheme={result.scheme}
                      matchResult={result}
                      onViewDetails={(s) => setSelectedSchemeForDetails(s)}
                    />
                  ))}
                </div>
              </div>
            )}
          </main>
        )}

        {/* VIEW 3: BROWSE ALL SCHEMES */}
        {currentView === 'browse' && (
          <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
            <div className="space-y-2">
              <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                Browse Official Government Schemes
              </h1>
              <p className="text-xs sm:text-sm text-slate-600">
                Search and explore our database of verified welfare schemes across Central and State Governments.
              </p>
            </div>

            {/* Filter Bar with Voice Search */}
            <SchemeFilterBar
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              selectedCategory={selectedCategory}
              onCategoryChange={setSelectedCategory}
              selectedState={selectedState}
              onStateChange={setSelectedState}
              selectedOccupation={selectedOccupation}
              onOccupationChange={setSelectedOccupation}
              onResetFilters={resetFilters}
            />

            {/* Scheme Cards Grid */}
            {loading ? (
              <div className="py-16 text-center space-y-3">
                <div className="w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto" />
                <p className="text-xs font-semibold text-slate-500">Loading verified schemes catalog...</p>
              </div>
            ) : filteredBrowseSchemes.length === 0 ? (
              <div className="bg-white rounded-3xl p-12 text-center space-y-4 border border-slate-200 max-w-md mx-auto">
                <p className="text-base font-bold text-slate-800">
                  No schemes match your active search filters.
                </p>
                <p className="text-xs text-slate-500">
                  Try clearing your search term or selecting "All India" for state coverage.
                </p>
                <button
                  onClick={resetFilters}
                  className="px-5 py-2.5 rounded-xl bg-slate-900 text-white font-bold text-xs"
                >
                  Reset Filters
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between text-xs text-slate-500 font-semibold">
                  <span>Found {filteredBrowseSchemes.length} schemes</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredBrowseSchemes.map((scheme) => (
                    <SchemeCard
                      key={scheme.id}
                      scheme={scheme}
                      onViewDetails={(s) => setSelectedSchemeForDetails(s)}
                    />
                  ))}
                </div>
              </div>
            )}
          </main>
        )}

        {/* VIEW 4: SAVED SCHEMES */}
        {currentView === 'saved' && (
          <main>
            <UserDashboard
              initialTab="saved"
              onViewDetails={(s) => setSelectedSchemeForDetails(s)}
              onOpenQuestionnaire={() => setIsQuestionnaireOpen(true)}
            />
          </main>
        )}

        {/* VIEW 5: REMINDERS DASHBOARD */}
        {currentView === 'reminders' && (
          <main>
            <UserDashboard
              initialTab="reminders"
              onViewDetails={(s) => setSelectedSchemeForDetails(s)}
              onOpenQuestionnaire={() => setIsQuestionnaireOpen(true)}
            />
          </main>
        )}

        {/* VIEW 6: ADMIN PORTAL */}
        {currentView === 'admin' && (
          <main>
            <AdminDashboard
              schemes={schemes}
              onRefreshSchemes={loadSchemes}
            />
          </main>
        )}
      </div>

      {/* Footer */}
      <Footer
        onNavigate={(view) => {
          setCurrentView(view as any);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenQuestionnaire={() => setIsQuestionnaireOpen(true)}
      />

      {/* Multi-step Eligibility Questionnaire Modal */}
      <QuestionnaireModal
        isOpen={isQuestionnaireOpen}
        onClose={() => setIsQuestionnaireOpen(false)}
        onComplete={handleQuestionnaireComplete}
        initialAnswers={userAnswers || undefined}
      />

      {/* Scheme Full Details Modal */}
      <SchemeDetailsModal
        scheme={selectedSchemeForDetails}
        userAnswers={userAnswers}
        onClose={() => setSelectedSchemeForDetails(null)}
      />

      {/* Grounded Scheme AI Assistant Modal */}
      <SchemeAssistantModal
        isOpen={isAssistantOpen}
        onClose={() => setIsAssistantOpen(false)}
        schemes={schemes}
        onViewSchemeDetails={(s) => setSelectedSchemeForDetails(s)}
      />
    </div>
  );
};

export default function App() {
  return (
    <LanguageProvider>
      <SimpleModeProvider>
        <SavedSchemesProvider>
          <AuthProvider>
            <SchemeSathiApp />
          </AuthProvider>
        </SavedSchemesProvider>
      </SimpleModeProvider>
    </LanguageProvider>
  );
}
