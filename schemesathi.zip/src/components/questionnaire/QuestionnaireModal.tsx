import React, { useState } from 'react';
import {
  X,
  ArrowRight,
  ArrowLeft,
  Check,
  Sparkles,
  Shield,
  MapPin,
  Briefcase,
  IndianRupee,
  GraduationCap,
  HeartHandshake,
  Home,
  User,
  Info
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { QuestionnaireAnswers, INITIAL_QUESTIONNAIRE_ANSWERS } from '../../types/questionnaire';
import { INDIAN_STATES_AND_UTS, DISTRICTS_BY_STATE } from '../../data/statesAndDistricts';
import { useLanguage } from '../../hooks/useLanguage';
import { AnalyticsService } from '../../services/analyticsService';

interface QuestionnaireModalProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: (answers: QuestionnaireAnswers) => void;
  initialAnswers?: QuestionnaireAnswers;
}

export const QuestionnaireModal: React.FC<QuestionnaireModalProps> = ({
  isOpen,
  onClose,
  onComplete,
  initialAnswers
}) => {
  const { t } = useLanguage();
  const [step, setStep] = useState(1);
  const totalSteps = 7;
  const [answers, setAnswers] = useState<QuestionnaireAnswers>(
    initialAnswers || INITIAL_QUESTIONNAIRE_ANSWERS
  );

  if (!isOpen) return null;

  const updateAnswers = (fields: Partial<QuestionnaireAnswers>) => {
    setAnswers((prev) => ({ ...prev, ...fields }));
  };

  const handleNext = () => {
    if (step === 1) {
      AnalyticsService.logEvent('questionnaire_started');
    }

    if (step < totalSteps) {
      setStep(step + 1);
    } else {
      // Finished questionnaire!
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch {
        // ignore
      }
      AnalyticsService.logEvent('questionnaire_completed', {
        state: answers.state,
        occupation: answers.occupation,
        incomeBracket: answers.incomeBracket
      });
      onComplete(answers);
      onClose();
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const availableDistricts = answers.state && DISTRICTS_BY_STATE[answers.state]
    ? DISTRICTS_BY_STATE[answers.state]
    : [];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header with Progress Bar */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold text-sm shadow-xs">
              {step}
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white leading-tight">
                {t.questionnaire.title}
              </h3>
              <p className="text-xs text-slate-400">
                {t.questionnaire.step_indicator.replace('{current}', String(step)).replace('{total}', String(totalSteps))}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close questionnaire"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress line */}
        <div className="w-full bg-slate-100 h-1.5">
          <div
            className="bg-indigo-600 h-1.5 transition-all duration-300 ease-out"
            style={{ width: `${(step / totalSteps) * 100}%` }}
          />
        </div>

        {/* Privacy reassurance pill */}
        <div className="bg-indigo-50/50 px-6 py-2.5 border-b border-indigo-100/60 flex items-center gap-2 text-xs text-indigo-900 font-medium">
          <Shield className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
          <span>{t.questionnaire.disclaimer}</span>
        </div>

        {/* Step Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* STEP 1: Age & Gender */}
          {step === 1 && (
            <div className="space-y-5 animate-in fade-in">
              <div className="flex items-center gap-2 text-slate-900 font-semibold text-base border-b border-slate-100 pb-2">
                <User className="w-5 h-5 text-indigo-600" />
                <span>{t.questionnaire.step1.title}</span>
              </div>
              <p className="text-xs text-slate-500">{t.questionnaire.step1.subtitle}</p>

              {/* Age Slider / Input */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-slate-700">
                  {t.questionnaire.step1.age_label}
                </label>
                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min="14"
                    max="90"
                    value={answers.age || 25}
                    onChange={(e) => updateAnswers({ age: parseInt(e.target.value, 10) })}
                    className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                  />
                  <span className="w-16 text-center font-bold text-slate-900 bg-slate-100 py-1.5 px-2 rounded-full border border-slate-200 text-sm">
                    {answers.age || 25} yrs
                  </span>
                </div>
              </div>

              {/* Gender Radio Chips */}
              <div className="space-y-2 pt-2">
                <label className="block text-xs font-semibold text-slate-700">
                  {t.questionnaire.step1.gender_label}
                </label>
                <div className="grid grid-cols-3 gap-2.5">
                  {[
                    { id: 'male', label: t.questionnaire.step1.gender_male },
                    { id: 'female', label: t.questionnaire.step1.gender_female },
                    { id: 'transgender', label: t.questionnaire.step1.gender_transgender }
                  ].map((g) => (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() => updateAnswers({ gender: g.id as any })}
                      className={`p-3 rounded-2xl border text-xs sm:text-sm font-semibold text-center transition-all cursor-pointer ${
                        answers.gender === g.id
                          ? 'bg-indigo-50 text-indigo-900 border-indigo-600 ring-2 ring-indigo-500/20'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {g.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: State & District Location */}
          {step === 2 && (
            <div className="space-y-5 animate-in fade-in">
              <div className="flex items-center gap-2 text-slate-900 font-semibold text-base border-b border-slate-100 pb-2">
                <MapPin className="w-5 h-5 text-indigo-600" />
                <span>{t.questionnaire.step2.title}</span>
              </div>
              <p className="text-xs text-slate-500">{t.questionnaire.step2.subtitle}</p>

              {/* State Selector */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-slate-700">
                  {t.questionnaire.step2.state_label}
                </label>
                <select
                  value={answers.state}
                  onChange={(e) => updateAnswers({ state: e.target.value, district: '' })}
                  className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:ring-2 focus:ring-indigo-600 focus:outline-hidden shadow-xs cursor-pointer"
                >
                  {INDIAN_STATES_AND_UTS.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>

              {/* District Selector (if available) */}
              {availableDistricts.length > 0 && (
                <div className="space-y-2">
                  <label className="block text-xs font-semibold text-slate-700">
                    {t.questionnaire.step2.district_label}
                  </label>
                  <select
                    value={answers.district || ''}
                    onChange={(e) => updateAnswers({ district: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:ring-2 focus:ring-indigo-600 focus:outline-hidden shadow-xs cursor-pointer"
                  >
                    <option value="">-- Select District (Optional) --</option>
                    {availableDistricts.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Area Type */}
              <div className="space-y-2 pt-2">
                <label className="block text-xs font-semibold text-slate-700">
                  {t.questionnaire.step2.area_type_label}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {[
                    { id: 'rural', label: t.questionnaire.step2.area_rural },
                    { id: 'urban', label: t.questionnaire.step2.area_urban },
                    { id: 'semi_urban', label: t.questionnaire.step2.area_semi }
                  ].map((a) => (
                    <button
                      key={a.id}
                      type="button"
                      onClick={() => updateAnswers({ areaType: a.id as any })}
                      className={`p-3 rounded-2xl border text-xs sm:text-sm font-medium text-left transition-all cursor-pointer ${
                        answers.areaType === a.id
                          ? 'bg-indigo-50 text-indigo-900 border-indigo-600 ring-2 ring-indigo-500/20 font-semibold'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {a.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: Occupation */}
          {step === 3 && (
            <div className="space-y-5 animate-in fade-in">
              <div className="flex items-center gap-2 text-slate-900 font-semibold text-base border-b border-slate-100 pb-2">
                <Briefcase className="w-5 h-5 text-indigo-600" />
                <span>{t.questionnaire.step3.title}</span>
              </div>
              <p className="text-xs text-slate-500">{t.questionnaire.step3.subtitle}</p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {[
                  { id: 'student', label: t.questionnaire.step3.student, icon: '🎓' },
                  { id: 'farmer', label: t.questionnaire.step3.farmer, icon: '🌾' },
                  { id: 'daily_wage_laborer', label: t.questionnaire.step3.daily_wage, icon: '🧱' },
                  { id: 'artisan_craftsperson', label: t.questionnaire.step3.artisan, icon: '🛠️' },
                  { id: 'self_employed_small_business', label: t.questionnaire.step3.self_employed, icon: '🏪' },
                  { id: 'salaried_private', label: t.questionnaire.step3.salaried, icon: '🏢' },
                  { id: 'unemployed', label: t.questionnaire.step3.unemployed, icon: '🔍' },
                  { id: 'homemaker', label: t.questionnaire.step3.homemaker, icon: '🏡' },
                  { id: 'retired_senior', label: t.questionnaire.step3.retired, icon: '👴' }
                ].map((occ) => (
                  <button
                    key={occ.id}
                    type="button"
                    onClick={() => updateAnswers({ occupation: occ.id as any })}
                    className={`p-3 rounded-2xl border text-xs sm:text-sm font-medium text-left flex items-center gap-2.5 transition-all cursor-pointer ${
                      answers.occupation === occ.id
                        ? 'bg-indigo-50 text-indigo-950 border-indigo-600 ring-2 ring-indigo-500/20 font-semibold shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-lg">{occ.icon}</span>
                    <span>{occ.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* STEP 4: Income Bracket */}
          {step === 4 && (
            <div className="space-y-5 animate-in fade-in">
              <div className="flex items-center gap-2 text-slate-900 font-semibold text-base border-b border-slate-100 pb-2">
                <IndianRupee className="w-5 h-5 text-indigo-600" />
                <span>{t.questionnaire.step4.title}</span>
              </div>
              <p className="text-xs text-slate-500">{t.questionnaire.step4.subtitle}</p>

              <div className="space-y-2">
                {[
                  { id: 'bpl_antyodaya', label: t.questionnaire.step4.bpl, priority: true },
                  { id: 'below_1_lakh', label: t.questionnaire.step4.under_1 },
                  { id: '1_to_2_5_lakh', label: t.questionnaire.step4['1_to_2_5'] },
                  { id: '2_5_to_5_lakh', label: t.questionnaire.step4['2_5_to_5'] },
                  { id: '5_to_8_lakh', label: t.questionnaire.step4['5_to_8'] },
                  { id: 'above_8_lakh', label: t.questionnaire.step4.above_8 }
                ].map((inc) => (
                  <button
                    key={inc.id}
                    type="button"
                    onClick={() => updateAnswers({ incomeBracket: inc.id as any })}
                    className={`w-full p-3 rounded-2xl border text-xs sm:text-sm font-medium text-left flex items-center justify-between transition-all cursor-pointer ${
                      answers.incomeBracket === inc.id
                        ? 'bg-indigo-50 text-indigo-950 border-indigo-600 ring-2 ring-indigo-500/20 font-semibold'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <span>{inc.label}</span>
                    {answers.incomeBracket === inc.id && (
                      <Check className="w-4 h-4 text-indigo-600 shrink-0" />
                    )}
                  </button>
                ))}
              </div>

              {/* Ration card checkbox */}
              <div className="pt-2">
                <label className="flex items-center gap-3 p-3 bg-slate-50 border border-slate-200 rounded-2xl cursor-pointer hover:bg-slate-100 transition-colors">
                  <input
                    type="checkbox"
                    checked={answers.hasBplOrRationCard || false}
                    onChange={(e) => updateAnswers({ hasBplOrRationCard: e.target.checked })}
                    className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-600"
                  />
                  <span className="text-xs sm:text-sm text-slate-800 font-medium">
                    {t.questionnaire.step4.ration_check}
                  </span>
                </label>
              </div>
            </div>
          )}

          {/* STEP 5: Category Specifics */}
          {step === 5 && (
            <div className="space-y-5 animate-in fade-in">
              <div className="flex items-center gap-2 text-slate-900 font-semibold text-base border-b border-slate-100 pb-2">
                <GraduationCap className="w-5 h-5 text-indigo-600" />
                <span>{t.questionnaire.step5.title}</span>
              </div>
              <p className="text-xs text-slate-500">{t.questionnaire.step5.subtitle}</p>

              {/* Student specific */}
              {answers.occupation === 'student' && (
                <div className="space-y-2">
                  <label className="block text-xs font-semibold text-slate-700">
                    {t.questionnaire.step5.student_level}
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {[
                      { id: 'pre_matric', label: 'Pre-Matric (Class 1 to 10)' },
                      { id: 'post_matric', label: 'Post-Matric (Class 11, 12, Diploma)' },
                      { id: 'undergraduate', label: 'Undergraduate (BA, BSc, BTech, etc.)' },
                      { id: 'postgraduate', label: 'Postgraduate / PhD / Research' },
                      { id: 'vocational_iti', label: 'Vocational / ITI / Skill Training' }
                    ].map((lvl) => (
                      <button
                        key={lvl.id}
                        type="button"
                        onClick={() => updateAnswers({ studentLevel: lvl.id as any })}
                        className={`p-3 rounded-xl border text-xs font-medium text-left transition-all cursor-pointer ${
                          answers.studentLevel === lvl.id
                            ? 'bg-indigo-50 text-indigo-900 border-indigo-600 font-semibold'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        {lvl.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Farmer specific */}
              {answers.occupation === 'farmer' && (
                <div className="space-y-2">
                  <label className="block text-xs font-semibold text-slate-700">
                    {t.questionnaire.step5.farmer_type}
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {[
                      { id: 'marginal', label: 'Marginal Farmer (< 2.5 Acres)' },
                      { id: 'small', label: 'Small Farmer (2.5 to 5 Acres)' },
                      { id: 'medium_large', label: 'Medium / Large Farmer (> 5 Acres)' },
                      { id: 'tenant_landless', label: 'Tenant Farmer / Landless Laborer' }
                    ].map((f) => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => updateAnswers({ farmerCategory: f.id as any })}
                        className={`p-3 rounded-xl border text-xs font-medium text-left transition-all cursor-pointer ${
                          answers.farmerCategory === f.id
                            ? 'bg-indigo-50 text-indigo-900 border-indigo-600 font-semibold'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Women welfare checks */}
              {answers.gender === 'female' && (
                <div className="space-y-2 pt-2">
                  <label className="block text-xs font-semibold text-slate-700">
                    Maternity / Family Status
                  </label>
                  <div className="space-y-2">
                    <label className="flex items-center gap-3 p-3 bg-slate-50 border border-slate-200 rounded-2xl cursor-pointer hover:bg-slate-100">
                      <input
                        type="checkbox"
                        checked={answers.isPregnantOrLactating || false}
                        onChange={(e) => updateAnswers({ isPregnantOrLactating: e.target.checked })}
                        className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-600"
                      />
                      <span className="text-xs sm:text-sm text-slate-800">
                        {t.questionnaire.step5.maternity_check} (PMMVY eligibility)
                      </span>
                    </label>

                    <label className="flex items-center gap-3 p-3 bg-slate-50 border border-slate-200 rounded-2xl cursor-pointer hover:bg-slate-100">
                      <input
                        type="checkbox"
                        checked={answers.isSingleWomanOrWidow || false}
                        onChange={(e) => updateAnswers({ isSingleWomanOrWidow: e.target.checked })}
                        className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-600"
                      />
                      <span className="text-xs sm:text-sm text-slate-800">
                        {t.questionnaire.step5.widow_check}
                      </span>
                    </label>
                  </div>
                </div>
              )}

              {answers.occupation !== 'student' && answers.occupation !== 'farmer' && answers.gender !== 'female' && (
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-600 flex items-center gap-2">
                  <Info className="w-4 h-4 text-slate-400 shrink-0" />
                  <span>No specialized target sub-questions needed for this profile. Click <strong>Next</strong> to proceed.</span>
                </div>
              )}
            </div>
          )}

          {/* STEP 6: Disability (Optional) */}
          {step === 6 && (
            <div className="space-y-5 animate-in fade-in">
              <div className="flex items-center gap-2 text-slate-900 font-semibold text-base border-b border-slate-100 pb-2">
                <HeartHandshake className="w-5 h-5 text-indigo-600" />
                <span>{t.questionnaire.step6.title}</span>
              </div>
              <p className="text-xs text-slate-500">{t.questionnaire.step6.subtitle}</p>

              <div className="space-y-3">
                <label className="block text-xs font-semibold text-slate-700">
                  {t.questionnaire.step6.disability_question}
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => updateAnswers({ hasDisability: true })}
                    className={`p-3 rounded-2xl border text-xs sm:text-sm font-semibold text-center transition-all cursor-pointer ${
                      answers.hasDisability
                        ? 'bg-indigo-50 text-indigo-900 border-indigo-600 ring-2 ring-indigo-500/20'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {t.questionnaire.step6.yes}
                  </button>
                  <button
                    type="button"
                    onClick={() => updateAnswers({ hasDisability: false })}
                    className={`p-3 rounded-2xl border text-xs sm:text-sm font-semibold text-center transition-all cursor-pointer ${
                      !answers.hasDisability
                        ? 'bg-indigo-50 text-indigo-900 border-indigo-600 ring-2 ring-indigo-500/20'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {t.questionnaire.step6.no}
                  </button>
                </div>
              </div>

              {answers.hasDisability && (
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-2xl text-xs text-blue-900 space-y-1">
                  <p className="font-semibold">Note on Assistive Schemes (ADIP & DEPwD):</p>
                  <p>{t.questionnaire.step6.udid_note}</p>
                </div>
              )}
            </div>
          )}

          {/* STEP 7: Social Category & Housing */}
          {step === 7 && (
            <div className="space-y-5 animate-in fade-in">
              <div className="flex items-center gap-2 text-slate-900 font-semibold text-base border-b border-slate-100 pb-2">
                <Home className="w-5 h-5 text-indigo-600" />
                <span>{t.questionnaire.step7.title}</span>
              </div>
              <p className="text-xs text-slate-500">{t.questionnaire.step7.subtitle}</p>

              {/* Social Category */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-slate-700">
                  {t.questionnaire.step7.social_category}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'general', label: t.questionnaire.step7.general },
                    { id: 'sc', label: t.questionnaire.step7.sc },
                    { id: 'st', label: t.questionnaire.step7.st },
                    { id: 'obc', label: t.questionnaire.step7.obc },
                    { id: 'minority', label: t.questionnaire.step7.minority }
                  ].map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => updateAnswers({ socialCategory: c.id as any })}
                      className={`p-3 rounded-xl border text-xs font-medium text-left transition-all cursor-pointer ${
                        answers.socialCategory === c.id
                          ? 'bg-indigo-50 text-indigo-900 border-indigo-600 font-semibold ring-2 ring-indigo-500/20'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {c.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Housing Condition */}
              <div className="space-y-2 pt-2">
                <label className="block text-xs font-semibold text-slate-700">
                  {t.questionnaire.step7.housing_type}
                </label>
                <div className="space-y-2">
                  {[
                    { id: 'kutcha', label: t.questionnaire.step7.kutcha },
                    { id: 'pucca', label: t.questionnaire.step7.pucca },
                    { id: 'rented', label: t.questionnaire.step7.rented }
                  ].map((h) => (
                    <button
                      key={h.id}
                      type="button"
                      onClick={() => updateAnswers({ housingType: h.id as any })}
                      className={`w-full p-3 rounded-xl border text-xs font-medium text-left transition-all cursor-pointer ${
                        answers.housingType === h.id
                          ? 'bg-indigo-50 text-indigo-900 border-indigo-600 font-semibold'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {h.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Navigation Buttons */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex items-center justify-between gap-3">
          {step > 1 ? (
            <button
              id="questionnaire-back-btn"
              type="button"
              onClick={handleBack}
              className="px-5 py-2.5 rounded-full text-xs sm:text-sm font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>{t.questionnaire.back}</span>
            </button>
          ) : (
            <div />
          )}

          <div className="flex items-center gap-2">
            {step < totalSteps && (
              <button
                type="button"
                onClick={handleNext}
                className="px-3 py-2 text-xs font-medium text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
              >
                {t.questionnaire.skip}
              </button>
            )}

            <button
              id="questionnaire-next-btn"
              type="button"
              onClick={handleNext}
              className="px-6 py-2.5 rounded-full text-xs sm:text-sm font-bold bg-indigo-600 text-white hover:bg-indigo-700 transition-all shadow-md flex items-center gap-2 cursor-pointer"
            >
              {step === totalSteps ? (
                <>
                  <Sparkles className="w-4 h-4 text-indigo-200" />
                  <span>{t.questionnaire.submit}</span>
                </>
              ) : (
                <>
                  <span>{t.questionnaire.next}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
