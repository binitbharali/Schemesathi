import React, { useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { VoiceService } from '../../services/voiceService';
import { useLanguage } from '../../hooks/useLanguage';

interface AudioNarratorProps {
  text: string;
  label?: string;
  className?: string;
  id?: string;
}

export const AudioNarrator: React.FC<AudioNarratorProps> = ({
  text,
  label = 'Listen',
  className = '',
  id
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const { language } = useLanguage();

  const handleToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isPlaying) {
      VoiceService.stopSpeaking();
      setIsPlaying(false);
    } else {
      VoiceService.speak(text, language);
      setIsPlaying(true);
      // Auto reset playing after estimated duration or cancel
      const wordCount = text.split(/\s+/).length;
      const estimatedMs = Math.max(3000, (wordCount / 2.5) * 1000);
      setTimeout(() => setIsPlaying(false), estimatedMs);
    }
  };

  if (!VoiceService.isSpeechSynthesisSupported()) {
    return null;
  }

  return (
    <button
      id={id || 'audio-narrator-btn'}
      type="button"
      onClick={handleToggle}
      aria-label={isPlaying ? 'Stop audio' : 'Listen to text'}
      className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-full transition-colors border cursor-pointer ${
        isPlaying
          ? 'bg-amber-100 text-amber-900 border-amber-300 animate-pulse'
          : 'bg-indigo-50/80 text-indigo-700 border-indigo-200/80 hover:bg-indigo-100'
      } ${className}`}
    >
      {isPlaying ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
      <span>{isPlaying ? 'Stop' : label}</span>
    </button>
  );
};
