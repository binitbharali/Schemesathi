import React from 'react';
import { ShieldCheck, CheckCircle2, RefreshCw, AlertTriangle, ExternalLink } from 'lucide-react';
import { useLanguage } from '../../hooks/useLanguage';

export const VerificationHighlight: React.FC = () => {
  const { t } = useLanguage();

  return (
    <section className="py-16 bg-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-300 bg-indigo-950 border border-indigo-700 px-3.5 py-1 rounded-full inline-flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Anti-Misinformation Architecture</span>
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {t.verification_section.title}
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed font-normal">
            {t.verification_section.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {/* Verified Badge Pillar */}
          <div className="bg-slate-800/80 border border-slate-700 rounded-3xl p-6 space-y-3">
            <div className="flex items-center gap-2.5">
              <span className="w-8 h-8 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center justify-center font-bold">
                ✓
              </span>
              <h3 className="text-sm font-bold text-emerald-300">
                {t.verification_section.badge_verified}
              </h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Every verified record has been manually reconciled with official ministry gazettes, guidelines PDFs, or live portals.
            </p>
            <div className="text-[11px] text-emerald-400 font-mono">
              Status: Verified & Validated
            </div>
          </div>

          {/* Review Pillar */}
          <div className="bg-slate-800/80 border border-slate-700 rounded-3xl p-6 space-y-3">
            <div className="flex items-center gap-2.5">
              <span className="w-8 h-8 rounded-xl bg-amber-950 text-amber-400 border border-amber-800 flex items-center justify-center font-bold">
                ⏳
              </span>
              <h3 className="text-sm font-bold text-amber-300">
                {t.verification_section.badge_needs_review}
              </h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Schemes undergoing annual revision or budget updates are flagged for nodal officer re-verification.
            </p>
            <div className="text-[11px] text-amber-400 font-mono">
              Status: Active Audit Required
            </div>
          </div>

          {/* Direct Government Portals */}
          <div className="bg-slate-800/80 border border-slate-700 rounded-3xl p-6 space-y-3">
            <div className="flex items-center gap-2.5">
              <span className="w-8 h-8 rounded-xl bg-indigo-950 text-indigo-400 border border-indigo-800 flex items-center justify-center font-bold">
                🌐
              </span>
              <h3 className="text-sm font-bold text-indigo-300">
                Direct Official Portals
              </h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              We never collect application fees or handle paperwork directly. All actions occur strictly on authorized .gov.in / .nic.in portals.
            </p>
            <div className="text-[11px] text-indigo-400 font-mono">
              Status: Direct Redirect Only
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
