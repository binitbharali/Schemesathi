import React from 'react';
import { FileQuestion, Cpu, ExternalLink, ArrowRight } from 'lucide-react';
import { useLanguage } from '../../hooks/useLanguage';

interface HowItWorksProps {
  onOpenQuestionnaire: () => void;
}

export const HowItWorks: React.FC<HowItWorksProps> = ({ onOpenQuestionnaire }) => {
  const { t } = useLanguage();

  const steps = [
    {
      step: '01',
      icon: FileQuestion,
      title: t.how_it_works.step1_title,
      desc: t.how_it_works.step1_desc,
      iconBg: 'bg-indigo-50 text-indigo-700 border-indigo-200'
    },
    {
      step: '02',
      icon: Cpu,
      title: t.how_it_works.step2_title,
      desc: t.how_it_works.step2_desc,
      iconBg: 'bg-blue-50 text-blue-700 border-blue-200'
    },
    {
      step: '03',
      icon: ExternalLink,
      title: t.how_it_works.step3_title,
      desc: t.how_it_works.step3_desc,
      iconBg: 'bg-teal-50 text-teal-700 border-teal-200'
    }
  ];

  return (
    <section className="py-16 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-3.5 py-1 rounded-full border border-indigo-100">
            Transparent Workflow
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-3 tracking-tight">
            {t.how_it_works.title}
          </h2>
          <p className="text-sm text-slate-500 mt-2 font-normal">
            {t.how_it_works.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {steps.map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-3xl p-6 border border-slate-100 shadow-xs hover:shadow-md hover:border-indigo-200 transition-all flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border ${item.iconBg}`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-2xl font-black text-slate-200">
                      {item.step}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 mb-2">
                    {item.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="text-center mt-10">
          <button
            onClick={onOpenQuestionnaire}
            className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer hover:-translate-y-0.5 active:scale-95"
          >
            <span>Start Eligibility Check</span>
            <ArrowRight className="w-4 h-4 text-indigo-200" />
          </button>
        </div>
      </div>
    </section>
  );
};
