import React from 'react';
import {
  GraduationCap,
  Sprout,
  Home,
  Briefcase,
  IndianRupee,
  UserCheck,
  HeartHandshake,
  Users,
  ChevronRight
} from 'lucide-react';
import { SchemeCategory } from '../../types/scheme';
import { useLanguage } from '../../hooks/useLanguage';

interface CategoriesGridProps {
  onSelectCategory: (category: SchemeCategory) => void;
}

export const CategoriesGrid: React.FC<CategoriesGridProps> = ({ onSelectCategory }) => {
  const { t } = useLanguage();

  const categories: {
    id: SchemeCategory;
    title: string;
    icon: string;
    description: string;
    iconBg: string;
    iconColor: string;
  }[] = [
    {
      id: 'education',
      title: t.categories.education,
      icon: '🎓',
      description: 'Pre-matric, post-matric scholarships, college fee waivers, higher research grants.',
      iconBg: 'bg-blue-100',
      iconColor: 'text-blue-600'
    },
    {
      id: 'agriculture',
      title: t.categories.agriculture,
      icon: '🌾',
      description: 'PM-KISAN DBT direct income, crop insurance, solar pumps, fertilizer subsidies.',
      iconBg: 'bg-green-100',
      iconColor: 'text-green-600'
    },
    {
      id: 'housing',
      title: t.categories.housing,
      icon: '🏠',
      description: 'Pradhan Mantri Awas Yojana (PMAY-Gramin & Urban), sanitation construction grants.',
      iconBg: 'bg-orange-100',
      iconColor: 'text-orange-600'
    },
    {
      id: 'employment',
      title: t.categories.employment,
      icon: '💼',
      description: 'PM SVANidhi street vendor loans, PM Vishwakarma craftsperson toolkit grants & MSME credit.',
      iconBg: 'bg-teal-100',
      iconColor: 'text-teal-600'
    },
    {
      id: 'financial_assistance',
      title: t.categories.financial_assistance,
      icon: '💰',
      description: 'Ayushman Bharat PM-JAY ₹5 Lakh health cover, Assam Orunodoi monthly financial aid.',
      iconBg: 'bg-indigo-100',
      iconColor: 'text-indigo-600'
    },
    {
      id: 'women_and_child',
      title: t.categories.women_and_child,
      icon: '👩',
      description: 'Pradhan Mantri Matru Vandana Yojana maternity cash incentives, Lakhpati Didi.',
      iconBg: 'bg-purple-100',
      iconColor: 'text-purple-600'
    },
    {
      id: 'senior_citizens',
      title: t.categories.senior_citizens,
      icon: '👵',
      description: 'Indira Gandhi National Old Age Pension (IGNOAPS), Atal Pension Yojana (APY).',
      iconBg: 'bg-slate-100',
      iconColor: 'text-slate-700'
    },
    {
      id: 'disability_support',
      title: t.categories.disability_support,
      icon: '♿',
      description: 'ADIP free assistive devices (wheelchairs, hearing aids), Divyangjan UDID scholarships.',
      iconBg: 'bg-sky-100',
      iconColor: 'text-sky-600'
    }
  ];

  return (
    <section className="py-16 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-3.5 py-1 rounded-full border border-indigo-100">
            Scheme Categories
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-3 tracking-tight">
            {t.categories.title}
          </h2>
          <p className="text-sm text-slate-500 mt-2 font-normal">
            {t.categories.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((cat) => (
            <div
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className="p-6 bg-white rounded-3xl border border-slate-100 shadow-xs hover:shadow-md hover:border-indigo-200 transition-all cursor-pointer group text-left flex flex-col justify-between"
            >
              <div>
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl mb-4 ${cat.iconBg}`}>
                  {cat.icon}
                </div>
                <h3 className="font-bold text-slate-800 group-hover:text-indigo-700 transition-colors mb-1 text-base">
                  {cat.title}
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  {cat.description}
                </p>
              </div>

              <div className="pt-4 mt-3 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-indigo-600 group-hover:text-indigo-800">
                <span>Explore Schemes</span>
                <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform text-indigo-500" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
