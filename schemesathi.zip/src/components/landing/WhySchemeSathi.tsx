import React from 'react';
import { ShieldCheck, Lock, Eye, Languages, Sparkles } from 'lucide-react';
import { useLanguage } from '../../hooks/useLanguage';

export const WhySchemeSathi: React.FC = () => {
  const { t } = useLanguage();

  const features = [
    {
      icon: Lock,
      title: t.why_schemesathi.privacy_title,
      desc: t.why_schemesathi.privacy_desc,
      iconBg: 'text-indigo-700 bg-indigo-50 border-indigo-200'
    },
    {
      icon: Eye,
      title: t.why_schemesathi.rule_engine_title,
      desc: t.why_schemesathi.rule_engine_desc,
      iconBg: 'text-blue-700 bg-blue-50 border-blue-200'
    },
    {
      icon: Languages,
      title: t.why_schemesathi.multilingual_title,
      desc: t.why_schemesathi.multilingual_desc,
      iconBg: 'text-teal-700 bg-teal-50 border-teal-200'
    },
    {
      icon: ShieldCheck,
      title: t.why_schemesathi.verified_title,
      desc: t.why_schemesathi.verified_desc,
      iconBg: 'text-amber-700 bg-amber-50 border-amber-200'
    }
  ];

  return (
    <section className="py-16 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-3.5 py-1 rounded-full border border-indigo-100">
            Citizen First Philosophy
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-3 tracking-tight">
            {t.why_schemesathi.title}
          </h2>
          <p className="text-sm text-slate-500 mt-2 font-normal">
            {t.why_schemesathi.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((f, i) => {
            const Icon = f.icon;
            return (
              <div
                key={i}
                className="p-6 rounded-3xl bg-white border border-slate-100 shadow-xs hover:shadow-md hover:border-indigo-200 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border mb-4 ${f.iconBg}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mb-2">
                    {f.title}
                  </h3>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    {f.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
