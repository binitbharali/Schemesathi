import React from 'react';
import { Sparkles, Search, Eye, ShieldCheck, CheckCircle2, ArrowRight, Lock } from 'lucide-react';
import { useLanguage } from '../../hooks/useLanguage';
import { useSimpleMode } from '../../hooks/useSimpleMode';

interface HeroProps {
  onOpenQuestionnaire: () => void;
  onBrowseSchemes: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenQuestionnaire, onBrowseSchemes }) => {
  const { t } = useLanguage();
  const { toggleSimpleMode } = useSimpleMode();

  return (
    <section className="relative overflow-hidden pt-10 pb-16 lg:pt-16 lg:pb-24 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-6">
          {/* Trust Pill */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 text-xs font-bold shadow-2xs">
            <ShieldCheck className="w-4 h-4 text-indigo-600" />
            <span>{t.hero.badge_verified}</span>
          </div>

          {/* Main Title */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-tight">
            Find Government Schemes You{' '}
            <span className="text-indigo-600 underline decoration-indigo-200 underline-offset-8">
              May Be Eligible For
            </span>
          </h1>

          {/* Subtitle description */}
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl mx-auto font-normal">
            {t.hero.subtitle}
          </p>

          {/* Primary Action Buttons */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4">
            <button
              id="hero-find-schemes-btn"
              onClick={onOpenQuestionnaire}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-base shadow-xl hover:shadow-2xl transition-all duration-200 flex items-center justify-center gap-2.5 hover:-translate-y-0.5 active:scale-95 cursor-pointer"
            >
              <Sparkles className="w-5 h-5 text-indigo-200" />
              <span>{t.hero.find_button}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              id="hero-browse-schemes-btn"
              onClick={onBrowseSchemes}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-white hover:bg-slate-50 text-slate-700 hover:text-indigo-700 font-bold text-base border-2 border-slate-200 hover:border-indigo-300 shadow-xs hover:shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Search className="w-5 h-5 text-slate-400" />
              <span>{t.hero.browse_button}</span>
            </button>
          </div>

          {/* Simple Mode Callout */}
          <div className="pt-2">
            <button
              id="hero-simple-mode-btn"
              onClick={toggleSimpleMode}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-100 hover:bg-amber-200 text-amber-900 text-xs sm:text-sm font-bold uppercase tracking-wide transition-all cursor-pointer shadow-2xs"
            >
              <Eye className="w-4 h-4 text-amber-700" />
              <span>{t.hero.simple_mode_button}</span>
            </button>
          </div>

          {/* Key Privacy Promises Bar */}
          <div className="pt-6 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-semibold text-slate-500 max-w-2xl mx-auto">
            <div className="flex items-center justify-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
              <span>No Aadhaar Numbers Needed</span>
            </div>
            <div className="flex items-center justify-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
              <span>Transparent Rule Engine</span>
            </div>
            <div className="flex items-center justify-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
              <span>Direct Ministry Portals</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
