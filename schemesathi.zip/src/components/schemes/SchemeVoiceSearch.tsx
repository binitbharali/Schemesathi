import React, { useState, useEffect } from 'react';
import { Mic, MicOff, Volume2, X, Sparkles } from 'lucide-react';
import { VoiceService } from '../../services/voiceService';
import { useLanguage } from '../../hooks/useLanguage';
import { AnalyticsService } from '../../services/analyticsService';

interface SchemeVoiceSearchProps {
  isOpen: boolean;
  onClose: () => void;
  onTranscript: (text: string) => void;
}

export const SchemeVoiceSearch: React.FC<SchemeVoiceSearchProps> = ({
  isOpen,
  onClose,
  onTranscript
}) => {
  const { language } = useLanguage();
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    let handle: { stop: () => void } | null = null;

    if (isOpen) {
      setError('');
      setTranscript('');
      setIsListening(true);
      AnalyticsService.logEvent('voice_search_used', { language });

      handle = VoiceService.startListening(
        language,
        (text) => {
          setTranscript(text);
        },
        (err) => {
          setError(err);
          setIsListening(false);
        },
        () => {
          setIsListening(false);
        }
      );
    }

    return () => {
      if (handle) handle.stop();
    };
  }, [isOpen, language]);

  if (!isOpen) return null;

  const handleApply = () => {
    if (transcript.trim()) {
      onTranscript(transcript.trim());
      onClose();
    }
  };

  const sampleVoicePrompts = [
    'Student scholarship for college',
    'Kisan samman nidhi loan',
    'Pradhan Mantri Awas pucca house',
    'Women financial assistance scheme',
    'Senior citizen pension'
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 p-6 space-y-6 text-center">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2.5 py-1 rounded-full">
            Voice Assistant Search
          </span>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Animated Mic icon */}
        <div className="flex justify-center">
          <div className={`w-20 h-20 rounded-full flex items-center justify-center transition-all ${
            isListening
              ? 'bg-red-100 text-red-600 ring-8 ring-red-100/50 animate-pulse scale-105'
              : 'bg-slate-100 text-slate-500'
          }`}>
            {isListening ? <Mic className="w-10 h-10" /> : <MicOff className="w-10 h-10" />}
          </div>
        </div>

        <div>
          <h3 className="text-base font-bold text-slate-900 mb-1">
            {isListening ? 'Listening... Speak your query now' : 'Voice Search'}
          </h3>
          <p className="text-xs text-slate-500">
            {isListening
              ? 'e.g. "Mujhe farmer subsidy chahiye" or "Scholarship for student"'
              : 'Microphone stopped.'}
          </p>
        </div>

        {/* Live transcription box */}
        <div className="min-h-16 p-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-sm font-medium flex items-center justify-center">
          {transcript ? (
            <span className="text-slate-900 font-semibold">"{transcript}"</span>
          ) : error ? (
            <span className="text-red-600 text-xs">{error}</span>
          ) : (
            <span className="text-slate-400 italic text-xs">Waiting for speech...</span>
          )}
        </div>

        {/* Sample Voice Prompts click-to-fill */}
        <div className="text-left space-y-1.5">
          <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Or try quick voice prompt:
          </p>
          <div className="flex flex-wrap gap-1.5">
            {sampleVoicePrompts.slice(0, 3).map((prompt, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setTranscript(prompt);
                  onTranscript(prompt);
                  onClose();
                }}
                className="text-[11px] px-2.5 py-1 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-900 rounded-lg text-slate-700 font-medium transition-colors"
              >
                "{prompt}"
              </button>
            ))}
          </div>
        </div>

        {/* Action button */}
        <div className="flex gap-2">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleApply}
            disabled={!transcript.trim()}
            className="flex-1 py-2.5 rounded-xl bg-emerald-700 text-white text-xs font-bold hover:bg-emerald-800 disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
          >
            Search Schemes
          </button>
        </div>
      </div>
    </div>
  );
};
