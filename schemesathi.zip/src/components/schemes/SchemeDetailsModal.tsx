import React, { useState, useEffect } from 'react';
import {
  X,
  ExternalLink,
  ShieldCheck,
  Building2,
  Calendar,
  FileText,
  ListOrdered,
  CheckCircle2,
  Bookmark,
  Bell,
  Sparkles,
  MapPin,
  Share2,
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import { Scheme, SchemeMatchResult } from '../../types/scheme';
import { QuestionnaireAnswers } from '../../types/questionnaire';
import { evaluateSchemeEligibility } from '../../services/recommendationEngine';
import { AudioNarrator } from '../common/AudioNarrator';
import { useLanguage } from '../../hooks/useLanguage';
import { useSavedSchemes } from '../../hooks/useSavedSchemes';
import { AnalyticsService } from '../../services/analyticsService';

interface SchemeDetailsModalProps {
  scheme: Scheme | null;
  userAnswers?: QuestionnaireAnswers | null;
  onClose: () => void;
}

export const SchemeDetailsModal: React.FC<SchemeDetailsModalProps> = ({
  scheme,
  userAnswers,
  onClose
}) => {
  const { language, t } = useLanguage();
  const { isSaved, saveScheme, removeSavedScheme } = useSavedSchemes();
  const [reminderDate, setReminderDate] = useState('');
  const [reminderNote, setReminderNote] = useState('');
  const [showReminderForm, setShowReminderForm] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  useEffect(() => {
    if (scheme) {
      AnalyticsService.logEvent('scheme_viewed', {
        schemeId: scheme.id,
        schemeName: scheme.name,
        category: scheme.category,
        state: scheme.state
      });
    }
  }, [scheme]);

  if (!scheme) return null;

  const saved = isSaved(scheme.id);

  // Localized text
  const displayName = language === 'hi' && scheme.name_hi
    ? scheme.name_hi
    : language === 'as' && scheme.name_as
    ? scheme.name_as
    : scheme.name;

  const displayDesc = language === 'hi' && scheme.description_hi
    ? scheme.description_hi
    : language === 'as' && scheme.description_as
    ? scheme.description_as
    : scheme.description;

  const displayBenefits = language === 'hi' && scheme.benefits_hi
    ? scheme.benefits_hi
    : language === 'as' && scheme.benefits_as
    ? scheme.benefits_as
    : scheme.benefits;

  const displayDocs = language === 'hi' && scheme.documents_hi
    ? scheme.documents_hi
    : language === 'as' && scheme.documents_as
    ? scheme.documents_as
    : scheme.documents;

  const displaySteps = language === 'hi' && scheme.application_steps_hi
    ? scheme.application_steps_hi
    : language === 'as' && scheme.application_steps_as
    ? scheme.application_steps_as
    : scheme.application_steps;

  // Calculate live match reasoning if user has answered questionnaire
  const matchResult: SchemeMatchResult | null = userAnswers
    ? evaluateSchemeEligibility(scheme, userAnswers)
    : null;

  const handleOfficialPortalClick = () => {
    AnalyticsService.logEvent('official_link_clicked', {
      schemeId: scheme.id,
      schemeName: scheme.name,
      url: scheme.official_url
    });
  };

  const handleSaveWithReminder = () => {
    saveScheme(scheme, reminderDate || undefined, reminderNote || undefined);
    setToastMessage(t.scheme_details.saved_success);
    setShowReminderForm(false);
    setTimeout(() => setToastMessage(''), 3000);
  };

  const speechText = `${displayName}. ${displayDesc}. Official benefit: ${scheme.benefits}. Key documents required: ${displayDocs.join(', ')}.`;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Top Header */}
        <div className="bg-slate-900 text-white p-6 border-b border-slate-800 flex items-start justify-between gap-4">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-semibold px-3 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                {scheme.category.replace(/_/g, ' ').toUpperCase()}
              </span>

              <span className="text-xs font-semibold px-3 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700 flex items-center gap-1">
                <MapPin className="w-3 h-3 text-slate-400" />
                <span>{scheme.state}</span>
              </span>

              {scheme.verification_status === 'verified' && (
                <span className="text-xs font-semibold px-3 py-0.5 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-700 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
                  <span>{t.scheme_details.verified_badge}</span>
                </span>
              )}
            </div>

            <h2 className="text-lg sm:text-2xl font-extrabold text-white leading-snug tracking-tight">
              {displayName}
            </h2>

            <p className="text-xs sm:text-sm text-slate-300 flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-indigo-400 shrink-0" />
              <span>{scheme.department}</span>
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors shrink-0 cursor-pointer"
            aria-label="Close details"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Action ribbon with Audio Narrator, Save, and Reminder */}
        <div className="bg-slate-50 px-6 py-3 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <AudioNarrator text={speechText} label={t.scheme_details.voice_readout} />
            <span className="text-xs text-slate-500 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              <span>{t.scheme_details.last_verified}: <strong>{scheme.last_verified}</strong></span>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (saved) {
                  removeSavedScheme(scheme.id);
                } else {
                  saveScheme(scheme);
                  setToastMessage(t.scheme_details.saved_success);
                  setTimeout(() => setToastMessage(''), 3000);
                }
              }}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition-colors border cursor-pointer ${
                saved
                  ? 'bg-indigo-100 text-indigo-900 border-indigo-300'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Bookmark className={`w-3.5 h-3.5 ${saved ? 'fill-indigo-800' : ''}`} />
              <span>{saved ? 'Saved in Dashboard' : t.scheme_details.save_scheme}</span>
            </button>

            <button
              onClick={() => setShowReminderForm(!showReminderForm)}
              className="px-3.5 py-1.5 rounded-full text-xs font-semibold bg-white text-slate-700 border border-slate-200 hover:bg-slate-50 flex items-center gap-1.5 cursor-pointer"
            >
              <Bell className="w-3.5 h-3.5 text-amber-600" />
              <span>Set Reminder</span>
            </button>
          </div>
        </div>

        {/* Toast confirmation */}
        {toastMessage && (
          <div className="bg-indigo-600 text-white text-xs py-2 px-4 text-center font-bold animate-in slide-in-from-top-1">
            {toastMessage}
          </div>
        )}

        {/* Reminder scheduling box */}
        {showReminderForm && (
          <div className="bg-amber-50 p-5 border-b border-amber-200 space-y-3 animate-in fade-in">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                <Bell className="w-4 h-4 text-amber-700" />
                <span>{t.scheme_details.set_reminder}</span>
              </span>
              <button
                onClick={() => setShowReminderForm(false)}
                className="text-xs text-slate-500 hover:text-slate-800 cursor-pointer"
              >
                Cancel
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Reminder Date
                </label>
                <input
                  type="date"
                  value={reminderDate}
                  onChange={(e) => setReminderDate(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-800"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Custom Reminder Note
                </label>
                <input
                  type="text"
                  placeholder={t.scheme_details.reminder_placeholder}
                  value={reminderNote}
                  onChange={(e) => setReminderNote(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-800"
                />
              </div>
            </div>
            <button
              onClick={handleSaveWithReminder}
              className="px-4 py-2 rounded-full bg-amber-600 text-white font-bold text-xs hover:bg-amber-700 cursor-pointer"
            >
              Save Scheme with Reminder
            </button>
          </div>
        )}

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-800 text-sm">
          {/* 1. About the Scheme */}
          <section className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              {t.scheme_details.about}
            </h4>
            <p className="text-sm text-slate-700 leading-relaxed bg-slate-50 p-4 rounded-2xl border border-slate-100">
              {displayDesc}
            </p>
          </section>

          {/* 2. Tangible Benefits */}
          <section className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              <span>{t.scheme_details.benefits}</span>
            </h4>
            <div className="p-4 bg-indigo-50/60 border border-indigo-100 rounded-2xl space-y-2">
              <p className="text-sm text-indigo-950 font-medium leading-relaxed">
                {displayBenefits}
              </p>
              {scheme.benefits_amount && (
                <div className="pt-2 border-t border-indigo-200/60 flex items-center justify-between text-xs">
                  <span className="text-indigo-800 font-semibold">Standard Financial Assistance / Coverage:</span>
                  <span className="font-bold text-indigo-950 bg-indigo-200/60 px-3 py-1 rounded-full">
                    {scheme.benefits_amount}
                  </span>
                </div>
              )}
            </div>
          </section>

          {/* 3. Why You Matched (Rule Transparency) */}
          {matchResult && matchResult.reasons.length > 0 && (
            <section className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />
                <span>{t.scheme_details.why_matched}</span>
              </h4>
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100 space-y-2">
                {matchResult.reasons.map((r, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs">
                    <span className={`w-4 h-4 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                      r.matched ? 'bg-indigo-100 text-indigo-800 font-bold' : 'bg-slate-200 text-slate-500'
                    }`}>
                      {r.matched ? '✓' : '•'}
                    </span>
                    <div>
                      <span className="font-semibold text-slate-900">{r.criterion}: </span>
                      <span className="text-slate-600">{r.description}</span>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* 4. Required Documents Checklist */}
          <section className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-indigo-600" />
              <span>{t.scheme_details.required_documents}</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {displayDocs.map((doc, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-white rounded-2xl border border-slate-200 text-xs text-slate-700 flex items-start gap-2 shadow-2xs"
                >
                  <span className="w-5 h-5 rounded-full bg-indigo-50 text-indigo-700 font-bold flex items-center justify-center shrink-0 text-[11px]">
                    {idx + 1}
                  </span>
                  <span className="leading-snug pt-0.5">{doc}</span>
                </div>
              ))}
            </div>
          </section>

          {/* 5. How to Apply Step-by-Step */}
          <section className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <ListOrdered className="w-3.5 h-3.5 text-indigo-600" />
              <span>{t.scheme_details.how_to_apply}</span>
            </h4>
            <div className="space-y-2.5">
              {displaySteps.map((stepText, idx) => (
                <div
                  key={idx}
                  className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 flex items-start gap-3 text-xs sm:text-sm text-slate-700"
                >
                  <span className="w-6 h-6 rounded-full bg-slate-900 text-white font-bold flex items-center justify-center shrink-0 text-xs">
                    {idx + 1}
                  </span>
                  <p className="leading-relaxed pt-0.5">{stepText}</p>
                </div>
              ))}
            </div>
          </section>

          {/* 6. Disclaimers and Source Verification */}
          <div className="p-4 bg-amber-50/80 rounded-2xl border border-amber-200 text-xs text-amber-950 space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold text-amber-900">
              <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
              <span>Official Verification Notice</span>
            </div>
            <p className="leading-relaxed">
              SchemeSathi is an informational assistance platform. Applications must be completed on official government portals. Verify latest deadlines and guidelines directly with {scheme.department}.
            </p>
          </div>
        </div>

        {/* Modal Bottom Footer Actions */}
        <div className="bg-slate-50 p-5 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-500 flex items-center gap-2">
            {scheme.source_url && (
              <a
                href={scheme.source_url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-slate-600 hover:text-indigo-700 underline flex items-center gap-1"
              >
                <span>{t.scheme_details.view_guidelines}</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="w-full sm:w-auto px-5 py-2.5 rounded-full border border-slate-200 text-xs sm:text-sm font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              Close
            </button>

            <a
              id="apply-official-portal-link"
              href={scheme.official_url}
              target="_blank"
              rel="noopener noreferrer"
              onClick={handleOfficialPortalClick}
              className="w-full sm:w-auto px-6 py-2.5 rounded-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-md transition-all hover:scale-[1.02] cursor-pointer"
            >
              <span>{t.scheme_details.apply_official}</span>
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
