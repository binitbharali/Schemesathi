import React, { useState } from 'react';
import {
  Bookmark,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
  ChevronRight,
  Info,
  Calendar,
  Building2,
  MapPin,
  Sparkles
} from 'lucide-react';
import { Scheme, SchemeMatchResult } from '../../types/scheme';
import { MatchScoreBadge } from './MatchScoreBadge';
import { AudioNarrator } from '../common/AudioNarrator';
import { useLanguage } from '../../hooks/useLanguage';
import { useSavedSchemes } from '../../hooks/useSavedSchemes';
import { AnalyticsService } from '../../services/analyticsService';

interface SchemeCardProps {
  matchResult?: SchemeMatchResult;
  scheme: Scheme;
  onViewDetails: (scheme: Scheme) => void;
}

export const SchemeCard: React.FC<SchemeCardProps> = ({
  matchResult,
  scheme,
  onViewDetails
}) => {
  const { language, t } = useLanguage();
  const { isSaved, saveScheme, removeSavedScheme } = useSavedSchemes();
  const [showAllReasons, setShowAllReasons] = useState(false);

  const saved = isSaved(scheme.id);

  // Localization fallback
  const displayName = language === 'hi' && scheme.name_hi
    ? scheme.name_hi
    : language === 'as' && scheme.name_as
    ? scheme.name_as
    : scheme.name;

  const displayDesc = language === 'hi' && scheme.description_hi
    ? scheme.description_hi
    : language === 'as' && scheme.description_as
    ? scheme.description_as
    : scheme.description;

  const handleSaveToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (saved) {
      removeSavedScheme(scheme.id);
    } else {
      saveScheme(scheme);
    }
  };

  const reasons = matchResult?.reasons.filter((r) => r.matched) || [];

  return (
    <div
      id={`scheme-card-${scheme.id}`}
      onClick={() => onViewDetails(scheme)}
      className="bg-white rounded-3xl border border-slate-100 hover:border-indigo-300 shadow-xs hover:shadow-md transition-all duration-200 p-6 flex flex-col justify-between cursor-pointer group relative"
    >
      {/* Card Header */}
      <div>
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex flex-wrap items-center gap-2">
            {matchResult && (
              <MatchScoreBadge tier={matchResult.tier} score={matchResult.matchScore} />
            )}

            <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
              <MapPin className="w-3 h-3 text-slate-400" />
              {scheme.state}
            </span>

            {scheme.verification_status === 'verified' && (
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                <ShieldCheck className="w-3 h-3 text-indigo-600" />
                Verified
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <AudioNarrator
              text={`${displayName}. ${displayDesc}`}
              className="hidden sm:inline-flex"
            />
            <button
              id={`save-btn-${scheme.id}`}
              type="button"
              onClick={handleSaveToggle}
              aria-label={saved ? 'Remove saved scheme' : 'Save scheme'}
              className={`p-2 rounded-full border transition-all cursor-pointer ${
                saved
                  ? 'bg-indigo-100 text-indigo-800 border-indigo-300'
                  : 'bg-slate-50 text-slate-400 border-slate-200 hover:bg-slate-100 hover:text-slate-700'
              }`}
            >
              <Bookmark className={`w-4 h-4 ${saved ? 'fill-indigo-800' : ''}`} />
            </button>
          </div>
        </div>

        {/* Scheme Title */}
        <h3 className="text-base sm:text-lg font-bold text-slate-900 group-hover:text-indigo-700 transition-colors leading-snug mb-1.5">
          {displayName}
        </h3>

        {/* Ministry / Department */}
        <p className="text-xs text-slate-500 flex items-center gap-1.5 mb-3 line-clamp-1">
          <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span>{scheme.department}</span>
        </p>

        {/* Description */}
        <p className="text-xs sm:text-sm text-slate-600 line-clamp-2 leading-relaxed mb-4">
          {displayDesc}
        </p>

        {/* Tangible Benefit Pill */}
        {scheme.benefits_amount && (
          <div className="mb-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-950 border border-emerald-200 text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>Benefit: {scheme.benefits_amount}</span>
          </div>
        )}

        {/* "Why you're seeing this" rule checklist */}
        {reasons.length > 0 && (
          <div className="bg-slate-50 rounded-2xl p-3.5 border border-slate-100 mb-4 space-y-1.5">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
              <Info className="w-3 h-3 text-indigo-600" />
              <span>{t.results.why_matched}</span>
            </div>
            <div className="space-y-1">
              {(showAllReasons ? reasons : reasons.slice(0, 2)).map((r, idx) => (
                <div key={idx} className="flex items-start gap-1.5 text-xs text-slate-700">
                  <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                  <span className="line-clamp-1">{r.description}</span>
                </div>
              ))}
            </div>
            {reasons.length > 2 && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowAllReasons(!showAllReasons);
                }}
                className="text-[11px] font-bold text-indigo-600 hover:underline pt-0.5 block cursor-pointer"
              >
                {showAllReasons ? 'Show less' : `+${reasons.length - 2} more criteria matches`}
              </button>
            )}
          </div>
        )}
      </div>

      {/* Card Footer */}
      <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
        <span className="text-[11px] text-slate-400 flex items-center gap-1">
          <Calendar className="w-3 h-3" />
          <span>Verified: {scheme.last_verified}</span>
        </span>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onViewDetails(scheme);
          }}
          className="inline-flex items-center gap-1 text-xs font-bold text-indigo-600 group-hover:text-indigo-800 hover:underline cursor-pointer"
        >
          <span>{t.results.view_details}</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
