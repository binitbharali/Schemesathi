import React, { useState } from 'react';
import { Search, Mic, Filter, X, MapPin, Check, SlidersHorizontal } from 'lucide-react';
import { SchemeCategory } from '../../types/scheme';
import { INDIAN_STATES_AND_UTS } from '../../data/statesAndDistricts';
import { SchemeVoiceSearch } from './SchemeVoiceSearch';
import { useLanguage } from '../../hooks/useLanguage';

interface SchemeFilterBarProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  selectedCategory: SchemeCategory | 'all';
  onCategoryChange: (cat: SchemeCategory | 'all') => void;
  selectedState: string;
  onStateChange: (st: string) => void;
  selectedOccupation: string;
  onOccupationChange: (occ: string) => void;
  onResetFilters: () => void;
}

export const SchemeFilterBar: React.FC<SchemeFilterBarProps> = ({
  searchQuery,
  onSearchChange,
  selectedCategory,
  onCategoryChange,
  selectedState,
  onStateChange,
  selectedOccupation,
  onOccupationChange,
  onResetFilters
}) => {
  const { t } = useLanguage();
  const [showVoiceModal, setShowVoiceModal] = useState(false);
  const [showFiltersDrawer, setShowFiltersDrawer] = useState(false);

  const categories: { id: SchemeCategory | 'all'; label: string; icon: string }[] = [
    { id: 'all', label: 'All Schemes', icon: '🌟' },
    { id: 'education', label: t.categories.education, icon: '🎓' },
    { id: 'agriculture', label: t.categories.agriculture, icon: '🌾' },
    { id: 'financial_assistance', label: t.categories.financial_assistance, icon: '💰' },
    { id: 'housing', label: t.categories.housing, icon: '🏠' },
    { id: 'employment', label: t.categories.employment, icon: '💼' },
    { id: 'women_and_child', label: t.categories.women_and_child, icon: '👩' },
    { id: 'senior_citizens', label: t.categories.senior_citizens, icon: '👵' },
    { id: 'disability_support', label: t.categories.disability_support, icon: '♿' }
  ];

  const occupations = [
    { id: 'all', label: 'All Occupations' },
    { id: 'student', label: 'Students' },
    { id: 'farmer', label: 'Farmers' },
    { id: 'artisan_craftsperson', label: 'Artisans / MSME' },
    { id: 'daily_wage_laborer', label: 'Daily Wage' },
    { id: 'self_employed_small_business', label: 'Small Business / Street Vendor' },
    { id: 'retired_senior', label: 'Senior Citizens' }
  ];

  const hasActiveFilters =
    searchQuery.trim() !== '' ||
    selectedCategory !== 'all' ||
    selectedState !== 'All India' ||
    selectedOccupation !== 'all';

  return (
    <div className="space-y-4">
      {/* Search Input Bar with Voice Trigger */}
      <div className="flex items-center gap-2.5">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
          <input
            id="scheme-search-input"
            type="text"
            placeholder="Search schemes by name, keyword, benefits, or department..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full pl-11 pr-10 py-3 bg-white border border-slate-200 rounded-full text-sm font-medium text-slate-800 placeholder:text-slate-400 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 focus:outline-hidden shadow-xs transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Voice Search Button */}
        <button
          id="voice-search-trigger-btn"
          type="button"
          onClick={() => setShowVoiceModal(true)}
          className="px-4 py-3 rounded-full bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 font-semibold text-xs flex items-center gap-1.5 transition-colors shrink-0 shadow-xs cursor-pointer"
          title="Voice Search"
        >
          <Mic className="w-4 h-4 text-indigo-600" />
          <span className="hidden sm:inline">Voice Search</span>
        </button>

        {/* State Quick Dropdown */}
        <div className="w-44 hidden md:block">
          <select
            value={selectedState}
            onChange={(e) => onStateChange(e.target.value)}
            className="w-full py-3 px-3.5 bg-white border border-slate-200 rounded-full text-xs font-semibold text-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 focus:outline-hidden shadow-xs transition-all cursor-pointer"
          >
            {INDIAN_STATES_AND_UTS.map((st) => (
              <option key={st} value={st}>
                {st}
              </option>
            ))}
          </select>
        </div>

        {/* Mobile Filters Toggle Button */}
        <button
          onClick={() => setShowFiltersDrawer(!showFiltersDrawer)}
          className="md:hidden px-4 py-3 rounded-full bg-white border border-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1.5 shadow-xs cursor-pointer"
        >
          <SlidersHorizontal className="w-4 h-4 text-slate-600" />
          <span>Filters</span>
        </button>
      </div>

      {/* Categories Horizontal Scroll Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none no-scrollbar">
        {categories.map((cat) => (
          <button
            key={cat.id}
            type="button"
            onClick={() => onCategoryChange(cat.id)}
            className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap flex items-center gap-1.5 transition-all border shrink-0 cursor-pointer ${
              selectedCategory === cat.id
                ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50 hover:border-slate-300'
            }`}
          >
            <span>{cat.icon}</span>
            <span>{cat.label}</span>
          </button>
        ))}
      </div>

      {/* Expanded Filter Options (State on mobile + Occupations) */}
      <div className={`pt-1 flex flex-wrap items-center justify-between gap-3 text-xs ${showFiltersDrawer ? 'block' : 'hidden md:flex'}`}>
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-slate-400 font-semibold text-[11px] uppercase tracking-wider">Filter Target:</span>
          {occupations.map((occ) => (
            <button
              key={occ.id}
              onClick={() => onOccupationChange(occ.id)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-colors border cursor-pointer ${
                selectedOccupation === occ.id
                  ? 'bg-slate-900 text-white border-slate-900 font-semibold'
                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
              }`}
            >
              {occ.label}
            </button>
          ))}
        </div>

        {hasActiveFilters && (
          <button
            onClick={onResetFilters}
            className="text-xs font-bold text-rose-600 hover:text-rose-700 flex items-center gap-1 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
            <span>Reset All Filters</span>
          </button>
        )}
      </div>

      {/* Voice Search Modal */}
      <SchemeVoiceSearch
        isOpen={showVoiceModal}
        onClose={() => setShowVoiceModal(false)}
        onTranscript={(text) => onSearchChange(text)}
      />
    </div>
  );
};
