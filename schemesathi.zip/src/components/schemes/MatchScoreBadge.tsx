import React from 'react';
import { Sparkles, CheckCircle, HelpCircle } from 'lucide-react';
import { MatchTier } from '../../types/scheme';
import { useLanguage } from '../../hooks/useLanguage';

interface MatchScoreBadgeProps {
  tier: MatchTier;
  score?: number;
}

export const MatchScoreBadge: React.FC<MatchScoreBadgeProps> = ({ tier, score }) => {
  const { t } = useLanguage();

  if (tier === 'strong') {
    return (
      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 shadow-2xs">
        <span className="w-2 h-2 rounded-full bg-indigo-600 animate-pulse" />
        <span>{t.results.strong_match}</span>
        {score !== undefined && <span className="text-[11px] opacity-80">({score}%)</span>}
      </span>
    );
  }

  if (tier === 'possible') {
    return (
      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-900 border border-amber-200">
        <span className="w-2 h-2 rounded-full bg-amber-500" />
        <span>{t.results.possible_match}</span>
        {score !== undefined && <span className="text-[11px] opacity-80">({score}%)</span>}
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200">
      <span className="w-2 h-2 rounded-full bg-slate-400" />
      <span>{t.results.general_match}</span>
    </span>
  );
};
