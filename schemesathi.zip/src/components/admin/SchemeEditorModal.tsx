import React, { useState } from 'react';
import { X, Save, ShieldCheck, AlertCircle } from 'lucide-react';
import { Scheme, SchemeCategory, VerificationStatus } from '../../types/scheme';
import { INDIAN_STATES_AND_UTS } from '../../data/statesAndDistricts';

interface SchemeEditorModalProps {
  scheme: Partial<Scheme> | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (schemeData: Partial<Scheme>) => void;
}

export const SchemeEditorModal: React.FC<SchemeEditorModalProps> = ({
  scheme,
  isOpen,
  onClose,
  onSave
}) => {
  const [formData, setFormData] = useState<Partial<Scheme>>({
    name: scheme?.name || '',
    name_hi: scheme?.name_hi || '',
    department: scheme?.department || '',
    category: scheme?.category || 'financial_assistance',
    state: scheme?.state || 'All India',
    description: scheme?.description || '',
    description_hi: scheme?.description_hi || '',
    benefits: scheme?.benefits || '',
    benefits_amount: scheme?.benefits_amount || '',
    official_url: scheme?.official_url || '',
    source_url: scheme?.source_url || '',
    verification_status: scheme?.verification_status || 'verified',
    last_verified: scheme?.last_verified || new Date().toISOString().split('T')[0],
    documents: scheme?.documents || ['Aadhaar Card', 'Income Certificate', 'Bank Passbook'],
    application_steps: scheme?.application_steps || ['Visit official portal', 'Fill details', 'Submit documents'],
    min_age: scheme?.min_age || 0,
    max_age: scheme?.max_age || 100,
    gender: scheme?.gender || 'all',
    max_income: scheme?.max_income || 500000,
    target_occupations: scheme?.target_occupations || ['all']
  });

  const [docsText, setDocsText] = useState(
    (scheme?.documents || ['Aadhaar Card', 'Income Certificate', 'Bank Passbook']).join('\n')
  );
  const [stepsText, setStepsText] = useState(
    (scheme?.application_steps || ['Visit official portal', 'Fill details', 'Submit documents']).join('\n')
  );

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedDocs = docsText.split('\n').map((s) => s.trim()).filter(Boolean);
    const updatedSteps = stepsText.split('\n').map((s) => s.trim()).filter(Boolean);

    onSave({
      ...formData,
      documents: updatedDocs,
      application_steps: updatedSteps
    });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-indigo-600 flex items-center justify-center text-white">
              <ShieldCheck className="w-5 h-5 text-indigo-100" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                {scheme?.id ? 'Edit Scheme Record' : 'Add New Verified Government Scheme'}
              </h3>
              <p className="text-[11px] text-slate-400">Strict eligibility rule definitions and source URLs</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-full hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 flex-1 text-xs sm:text-sm">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Scheme Name (English) *
              </label>
              <input
                type="text"
                required
                value={formData.name || ''}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium focus:ring-2 focus:ring-indigo-600 focus:bg-white focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Scheme Name (Hindi)
              </label>
              <input
                type="text"
                value={formData.name_hi || ''}
                onChange={(e) => setFormData({ ...formData, name_hi: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium focus:ring-2 focus:ring-indigo-600 focus:bg-white focus:outline-hidden"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Ministry / Department *
              </label>
              <input
                type="text"
                required
                value={formData.department || ''}
                onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium focus:ring-2 focus:ring-indigo-600 focus:bg-white focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Category *
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value as SchemeCategory })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium focus:ring-2 focus:ring-indigo-600 focus:bg-white focus:outline-hidden cursor-pointer"
              >
                <option value="education">Education</option>
                <option value="agriculture">Agriculture</option>
                <option value="financial_assistance">Financial Assistance</option>
                <option value="housing">Housing</option>
                <option value="employment">Employment</option>
                <option value="women_and_child">Women & Child</option>
                <option value="senior_citizens">Senior Citizens</option>
                <option value="disability_support">Disability Support</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                State Coverage *
              </label>
              <select
                value={formData.state}
                onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium focus:ring-2 focus:ring-indigo-600 focus:bg-white focus:outline-hidden cursor-pointer"
              >
                {INDIAN_STATES_AND_UTS.map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Description (English) *
            </label>
            <textarea
              rows={3}
              required
              value={formData.description || ''}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium focus:ring-2 focus:ring-indigo-600 focus:bg-white focus:outline-hidden"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Benefits Description *
              </label>
              <input
                type="text"
                required
                value={formData.benefits || ''}
                onChange={(e) => setFormData({ ...formData, benefits: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium focus:ring-2 focus:ring-indigo-600 focus:bg-white focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Benefit Amount / Tag (e.g. ₹6,000 / yr)
              </label>
              <input
                type="text"
                value={formData.benefits_amount || ''}
                onChange={(e) => setFormData({ ...formData, benefits_amount: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium focus:ring-2 focus:ring-indigo-600 focus:bg-white focus:outline-hidden"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Official Portal Application URL *
              </label>
              <input
                type="url"
                required
                placeholder="https://..."
                value={formData.official_url || ''}
                onChange={(e) => setFormData({ ...formData, official_url: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium focus:ring-2 focus:ring-indigo-600 focus:bg-white focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Source Guidelines URL
              </label>
              <input
                type="url"
                placeholder="https://..."
                value={formData.source_url || ''}
                onChange={(e) => setFormData({ ...formData, source_url: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium focus:ring-2 focus:ring-indigo-600 focus:bg-white focus:outline-hidden"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Required Documents (one per line)
              </label>
              <textarea
                rows={3}
                value={docsText}
                onChange={(e) => setDocsText(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-mono text-xs focus:ring-2 focus:ring-indigo-600 focus:bg-white focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Application Steps (one per line)
              </label>
              <textarea
                rows={3}
                value={stepsText}
                onChange={(e) => setStepsText(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-mono text-xs focus:ring-2 focus:ring-indigo-600 focus:bg-white focus:outline-hidden"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-200">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Verification Status
              </label>
              <select
                value={formData.verification_status}
                onChange={(e) => setFormData({ ...formData, verification_status: e.target.value as VerificationStatus })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium focus:ring-2 focus:ring-indigo-600 focus:bg-white focus:outline-hidden cursor-pointer"
              >
                <option value="verified">Verified (Official Source Checked)</option>
                <option value="needs_review">Needs Review (Audit Pending)</option>
                <option value="outdated">Outdated / Archived</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Last Verified Date
              </label>
              <input
                type="date"
                value={formData.last_verified}
                onChange={(e) => setFormData({ ...formData, last_verified: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium focus:ring-2 focus:ring-indigo-600 focus:bg-white focus:outline-hidden cursor-pointer"
              />
            </div>
          </div>

          <div className="pt-4 flex justify-end gap-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-full border border-slate-200 text-slate-700 hover:bg-slate-100 font-semibold text-xs sm:text-sm cursor-pointer transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-full bg-indigo-600 text-white font-bold text-xs sm:text-sm hover:bg-indigo-700 flex items-center gap-1.5 shadow-md cursor-pointer transition-colors"
            >
              <Save className="w-4 h-4" />
              <span>Save Scheme Record</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
