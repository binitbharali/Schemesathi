import React, { useState } from 'react';
import {
  ShieldCheck,
  Plus,
  Edit2,
  Trash2,
  Search,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  BarChart3,
  RefreshCw,
  Eye,
  FileCheck,
  Activity,
  Download,
  Users
} from 'lucide-react';
import { Scheme, VerificationStatus } from '../../types/scheme';
import { SchemeEditorModal } from './SchemeEditorModal';
import { SchemeService } from '../../services/schemeService';
import { AnalyticsService } from '../../services/analyticsService';

interface AdminDashboardProps {
  schemes: Scheme[];
  onRefreshSchemes: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  schemes,
  onRefreshSchemes
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<'all' | VerificationStatus>('all');
  const [selectedSchemeForEdit, setSelectedSchemeForEdit] = useState<Partial<Scheme> | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'schemes' | 'analytics' | 'audit'>('schemes');
  const [feedbackMessage, setFeedbackMessage] = useState('');

  const analyticsSummary = AnalyticsService.getAnalyticsSummary();

  const totalSchemes = schemes.length;
  const verifiedSchemes = schemes.filter((s) => s.verification_status === 'verified').length;
  const needsReviewSchemes = schemes.filter((s) => s.verification_status === 'needs_review').length;
  const distinctStates = Array.from(new Set(schemes.map((s) => s.state))).length;

  const filteredSchemes = schemes.filter((s) => {
    if (selectedStatusFilter !== 'all' && s.verification_status !== selectedStatusFilter) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        s.name.toLowerCase().includes(q) ||
        s.department.toLowerCase().includes(q) ||
        s.state.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleSaveScheme = async (schemeData: Partial<Scheme>) => {
    if (schemeData.id) {
      await SchemeService.updateScheme(schemeData.id, schemeData);
      setFeedbackMessage('Scheme updated successfully.');
    } else {
      await SchemeService.createScheme(schemeData as any);
      setFeedbackMessage('New scheme created and published to database.');
    }
    setIsEditorOpen(false);
    setSelectedSchemeForEdit(null);
    onRefreshSchemes();
    setTimeout(() => setFeedbackMessage(''), 3500);
  };

  const handleDeleteScheme = async (id: string) => {
    if (confirm('Are you sure you want to remove this scheme record?')) {
      await SchemeService.deleteScheme(id);
      setFeedbackMessage('Scheme removed.');
      onRefreshSchemes();
      setTimeout(() => setFeedbackMessage(''), 3500);
    }
  };

  const handleToggleStatus = async (scheme: Scheme) => {
    const nextStatus: VerificationStatus =
      scheme.verification_status === 'verified' ? 'needs_review' : 'verified';
    await SchemeService.updateVerificationStatus(scheme.id, nextStatus);
    onRefreshSchemes();
  };

  const handleResetToDefaults = () => {
    if (confirm('Reset to standard SIH official 12-scheme verified dataset?')) {
      SchemeService.resetToDefaults();
      onRefreshSchemes();
      setFeedbackMessage('Reset to official reference dataset.');
      setTimeout(() => setFeedbackMessage(''), 3500);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner */}
      <div className="bg-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border border-slate-800">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-3 py-1 rounded-full flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-indigo-400" />
              <span>Nodal Officer & Admin Portal</span>
            </span>
            <span className="text-xs font-semibold text-slate-400">SIH 2026</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
            Scheme Data Management & Verification
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
            Manage scheme catalog, perform periodic rule reconciliation against official gazettes, verify source URLs, and audit real-time citizen search patterns.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => {
              setSelectedSchemeForEdit(null);
              setIsEditorOpen(true);
            }}
            className="px-5 py-2.5 rounded-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Scheme</span>
          </button>

          <button
            onClick={handleResetToDefaults}
            className="px-4 py-2.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs border border-slate-700 flex items-center gap-1.5 cursor-pointer transition-colors"
            title="Reset to official seed data"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset Data</span>
          </button>
        </div>
      </div>

      {feedbackMessage && (
        <div className="bg-indigo-600 text-white text-xs sm:text-sm py-2.5 px-4 rounded-full font-bold text-center shadow-md animate-in slide-in-from-top-2">
          {feedbackMessage}
        </div>
      )}

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Total Schemes</span>
            <FileCheck className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-slate-900">{totalSchemes}</div>
          <p className="text-[11px] text-slate-400">Across Central & State Govts</p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Verified Records</span>
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-700">{verifiedSchemes}</div>
          <p className="text-[11px] text-emerald-600 font-medium">100% Grounded on Portals</p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Needs Review</span>
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-amber-600">{needsReviewSchemes}</div>
          <p className="text-[11px] text-slate-400">Annual Audit Queue</p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Logged Queries</span>
            <Activity className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-indigo-900">{analyticsSummary.totalEvents}</div>
          <p className="text-[11px] text-slate-400">Anonymous SIH telemetry</p>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex items-center gap-3 border-b border-slate-200">
        <button
          onClick={() => setActiveTab('schemes')}
          className={`pb-3.5 px-4 text-xs sm:text-sm font-bold border-b-2 transition-all cursor-pointer ${
            activeTab === 'schemes'
              ? 'text-indigo-600 border-indigo-600'
              : 'text-slate-500 border-transparent hover:text-slate-800'
          }`}
        >
          Scheme Catalog ({filteredSchemes.length})
        </button>

        <button
          onClick={() => setActiveTab('analytics')}
          className={`pb-3.5 px-4 text-xs sm:text-sm font-bold border-b-2 transition-all cursor-pointer ${
            activeTab === 'analytics'
              ? 'text-indigo-600 border-indigo-600'
              : 'text-slate-500 border-transparent hover:text-slate-800'
          }`}
        >
          SIH Usage Analytics
        </button>
      </div>

      {/* TAB 1: SCHEME CATALOG TABLE */}
      {activeTab === 'schemes' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search catalog by name or department..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 bg-white border border-slate-200 rounded-full text-xs font-medium text-slate-800 focus:ring-2 focus:ring-indigo-600 focus:outline-hidden shadow-xs"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <span className="text-xs font-semibold text-slate-500">Status:</span>
              <select
                value={selectedStatusFilter}
                onChange={(e) => setSelectedStatusFilter(e.target.value as any)}
                className="px-4 py-2 bg-white border border-slate-200 rounded-full text-xs font-medium text-slate-800 shadow-xs cursor-pointer focus:ring-2 focus:ring-indigo-600 focus:outline-hidden"
              >
                <option value="all">All Statuses</option>
                <option value="verified">Verified Only</option>
                <option value="needs_review">Needs Review Only</option>
              </select>
            </div>
          </div>

          {/* Table Container */}
          <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  <tr>
                    <th className="py-4 px-5">Scheme Name & Ministry</th>
                    <th className="py-4 px-5">Category</th>
                    <th className="py-4 px-5">State</th>
                    <th className="py-4 px-5">Status & Last Verified</th>
                    <th className="py-4 px-5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {filteredSchemes.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-4 px-5 max-w-xs">
                        <div className="font-bold text-slate-900 text-sm leading-snug">{s.name}</div>
                        <div className="text-[11px] text-slate-500 truncate">{s.department}</div>
                      </td>

                      <td className="py-4 px-5">
                        <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-semibold uppercase text-[10px]">
                          {s.category.replace(/_/g, ' ')}
                        </span>
                      </td>

                      <td className="py-4 px-5 whitespace-nowrap">
                        <span className="text-slate-800 font-semibold">{s.state}</span>
                      </td>

                      <td className="py-4 px-5 whitespace-nowrap">
                        <button
                          onClick={() => handleToggleStatus(s)}
                          className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold border transition-colors cursor-pointer ${
                            s.verification_status === 'verified'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                              : 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
                          }`}
                          title="Click to toggle status"
                        >
                          {s.verification_status === 'verified' ? (
                            <>
                              <ShieldCheck className="w-3 h-3 text-emerald-600" />
                              <span>Verified</span>
                            </>
                          ) : (
                            <>
                              <AlertTriangle className="w-3 h-3 text-amber-600" />
                              <span>Needs Review</span>
                            </>
                          )}
                        </button>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          {s.last_verified}
                        </div>
                      </td>

                      <td className="py-4 px-5 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <a
                            href={s.official_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 cursor-pointer"
                            title="Visit Official Portal"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>

                          <button
                            onClick={() => {
                              setSelectedSchemeForEdit(s);
                              setIsEditorOpen(true);
                            }}
                            className="p-1.5 text-indigo-600 hover:text-indigo-800 rounded-full hover:bg-indigo-50 cursor-pointer"
                            title="Edit Scheme Details"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => handleDeleteScheme(s.id)}
                            className="p-1.5 text-rose-500 hover:text-rose-700 rounded-full hover:bg-rose-50 cursor-pointer"
                            title="Delete Scheme"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: SIH USAGE ANALYTICS */}
      {activeTab === 'analytics' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Event Distribution */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-indigo-600" />
                <span>Anonymous Event Breakdown</span>
              </h3>
              <div className="space-y-2.5">
                {Object.entries(analyticsSummary.eventCounts).map(([eventName, count]) => (
                  <div key={eventName} className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-700 capitalize">
                      {eventName.replace(/_/g, ' ')}
                    </span>
                    <span className="font-bold text-slate-900 bg-slate-100 px-2.5 py-0.5 rounded-full">
                      {count}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Top Visited Schemes */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-600" />
                <span>Citizen Engagement Summary</span>
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                All analytics in SchemeSathi are strictly anonymized, zero-PII metrics designed for nodal policy evaluators to determine which welfare schemes experience highest discovery interest vs official portal link-throughs.
              </p>
              <div className="p-4 bg-indigo-50/50 border border-indigo-100 rounded-2xl text-xs text-indigo-950 space-y-1">
                <div className="font-bold">Total Scheme Clicks Tracked: {analyticsSummary.totalEvents}</div>
                <div>Data Source: Anonymous Browser Session & Supabase Logging</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Scheme Editor Modal */}
      <SchemeEditorModal
        scheme={selectedSchemeForEdit}
        isOpen={isEditorOpen}
        onClose={() => {
          setIsEditorOpen(false);
          setSelectedSchemeForEdit(null);
        }}
        onSave={handleSaveScheme}
      />
    </div>
  );
};
