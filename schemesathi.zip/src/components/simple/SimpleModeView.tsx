import React, { useState } from 'react';
import {
  Volume2,
  VolumeX,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle,
  Eye,
  Bookmark,
  ExternalLink,
  ShieldCheck,
  Building2,
  MapPin,
  RefreshCw
} from 'lucide-react';
import { Scheme } from '../../types/scheme';
import { INDIAN_STATES_AND_UTS } from '../../data/statesAndDistricts';
import { VoiceService } from '../../services/voiceService';
import { useLanguage } from '../../hooks/useLanguage';
import { useSavedSchemes } from '../../hooks/useSavedSchemes';
import { useSimpleMode } from '../../hooks/useSimpleMode';

interface SimpleModeViewProps {
  schemes: Scheme[];
  onViewDetails: (scheme: Scheme) => void;
  onOpenQuestionnaire?: () => void;
  onOpenAssistant?: () => void;
  onNavigate?: (view: 'home' | 'browse' | 'results' | 'saved' | 'reminders' | 'admin') => void;
}

export const SimpleModeView: React.FC<SimpleModeViewProps> = ({
  schemes,
  onViewDetails,
  onOpenQuestionnaire,
  onOpenAssistant,
  onNavigate
}) => {
  const { language, t } = useLanguage();
  const { toggleSimpleMode, setSimpleMode } = useSimpleMode();
  const { savedSchemes, isSaved, saveScheme, removeSavedScheme } = useSavedSchemes();

  const [step, setStep] = useState(1);
  const [selectedState, setSelectedState] = useState('All India');
  const [selectedOccupation, setSelectedOccupation] = useState('');
  const [selectedIncome, setSelectedIncome] = useState('');
  const [activeSpeech, setActiveSpeech] = useState<string | null>(null);

  const speak = (text: string, id: string) => {
    if (activeSpeech === id) {
      VoiceService.stopSpeaking();
      setActiveSpeech(null);
    } else {
      VoiceService.speak(text, language);
      setActiveSpeech(id);
    }
  };

  // Simple filter calculation with robust property checks
  const filteredSchemes = schemes.filter((s) => {
    if (selectedState !== 'All India' && s.state !== 'All India' && s.state !== selectedState) {
      return false;
    }
    if (selectedOccupation && selectedOccupation !== 'all') {
      if (
        s.occupations &&
        s.occupations.length > 0 &&
        !s.occupations.includes('all') &&
        !s.occupations.includes(selectedOccupation)
      ) {
        return false;
      }
    }
    if (selectedIncome && selectedIncome !== 'any') {
      if (s.income_limit) {
        const incomeLimits: Record<string, number> = {
          bpl_antyodaya: 75000,
          below_1_lakh: 100000,
          '1_to_2_5_lakh': 250000
        };
        const userInc = incomeLimits[selectedIncome];
        if (userInc && s.income_limit < userInc) {
          return false;
        }
      }
    }
    return true;
  });

  const occupations = [
    { id: 'farmer', label: '🌾 Farmer / Kisan', text: 'Farmer or Kisan agriculture related schemes' },
    { id: 'student', label: '🎓 Student / Padhaai', text: 'Student scholarships and education fee waivers' },
    { id: 'artisan_craftsperson', label: '🛠️ Artisan / Karigar', text: 'Artisan craftsperson toolkits and loans' },
    { id: 'self_employed_small_business', label: '🏪 Small Vendor / Dukan', text: 'Street vendors and small business support' },
    { id: 'retired_senior', label: '👴 Senior / Vridha', text: 'Senior citizens old age monthly pension' },
    { id: 'all', label: '👥 Any Other / General', text: 'General welfare and health insurance for all' }
  ];

  const incomes = [
    { id: 'bpl_antyodaya', label: 'Ration / BPL Card (Very Low Income)', desc: 'Eligible for maximum priority welfare assistance' },
    { id: 'below_1_lakh', label: 'Income Below ₹1 Lakh / Year', desc: 'Eligible for wide range of grants & subsidies' },
    { id: '1_to_2_5_lakh', label: 'Income ₹1 to 2.5 Lakh / Year', desc: 'Eligible for education & health coverage' },
    { id: 'any', label: 'Any Income / Not Sure', desc: 'Show all applicable schemes regardless of income' }
  ];

  const handleResetFilters = () => {
    setSelectedState('All India');
    setSelectedOccupation('');
    setSelectedIncome('');
    setStep(1);
    VoiceService.stopSpeaking();
    setActiveSpeech(null);
  };

  return (
    <div className="min-h-screen bg-amber-50/40 p-4 sm:p-6 lg:p-8 text-slate-900">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Simple Mode Header Banner */}
        <div className="bg-amber-400 border-2 border-amber-600 rounded-3xl p-5 sm:p-6 shadow-md flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center sm:text-left">
            <div className="flex items-center justify-center sm:justify-start gap-2">
              <Eye className="w-6 h-6 text-slate-900" />
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                {t.simple_mode.title}
              </h1>
            </div>
            <p className="text-sm font-semibold text-slate-900">
              {t.simple_mode.subtitle}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {onOpenAssistant && (
              <button
                onClick={onOpenAssistant}
                className="px-4 py-2.5 rounded-full bg-white text-indigo-900 font-bold text-xs sm:text-sm hover:bg-slate-50 transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-indigo-600" />
                <span>AI Voice Help</span>
              </button>
            )}
            <button
              onClick={() => {
                VoiceService.stopSpeaking();
                setSimpleMode(false);
              }}
              className="px-5 py-2.5 rounded-full bg-slate-900 text-white font-bold text-xs sm:text-sm hover:bg-slate-800 transition-colors shrink-0 shadow-xs cursor-pointer"
            >
              Switch to Standard View
            </button>
          </div>
        </div>

        {/* Quick Shortcut Pills in Simple Mode */}
        <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 text-xs font-semibold">
          <span className="text-slate-500 font-bold">Quick Actions:</span>
          {onOpenQuestionnaire && (
            <button
              onClick={onOpenQuestionnaire}
              className="px-3.5 py-1.5 bg-white border border-amber-300 hover:border-amber-500 rounded-full text-slate-800 flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>Full Eligibility Questionnaire</span>
            </button>
          )}
          {onNavigate && (
            <button
              onClick={() => onNavigate('browse')}
              className="px-3.5 py-1.5 bg-white border border-slate-200 hover:border-indigo-400 rounded-full text-slate-800 flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <Building2 className="w-3.5 h-3.5 text-indigo-600" />
              <span>Browse All {schemes.length} Schemes</span>
            </button>
          )}
          {onNavigate && (
            <button
              onClick={() => onNavigate('saved')}
              className="px-3.5 py-1.5 bg-white border border-slate-200 hover:border-emerald-400 rounded-full text-slate-800 flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <Bookmark className="w-3.5 h-3.5 text-emerald-600" />
              <span>Saved Schemes ({savedSchemes.length})</span>
            </button>
          )}
        </div>

        {/* 4-Step Simplified Wizard or Results View */}
        {step <= 3 ? (
          <div className="bg-white rounded-3xl border-2 border-slate-300 p-6 sm:p-8 shadow-lg space-y-6">
            {/* Step 1: Choose Your State */}
            {step === 1 && (
              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg sm:text-2xl font-black text-slate-900">
                    Step 1: Choose Your State
                  </h2>
                  <button
                    onClick={() => speak('Step 1: Choose your state from the dropdown list.', 'step1-audio')}
                    className="px-3 py-1.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer hover:bg-amber-200"
                  >
                    {activeSpeech === 'step1-audio' ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                    <span>Listen</span>
                  </button>
                </div>

                <p className="text-sm font-medium text-slate-600">
                  Select where you live in India to see schemes available for your area:
                </p>

                <select
                  value={selectedState}
                  onChange={(e) => setSelectedState(e.target.value)}
                  className="w-full text-base sm:text-lg font-bold p-4 bg-slate-50 border-2 border-slate-300 rounded-2xl focus:border-indigo-600 focus:outline-hidden cursor-pointer"
                >
                  {INDIAN_STATES_AND_UTS.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>

                <div className="pt-2">
                  <button
                    onClick={() => setStep(2)}
                    className="w-full py-4 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white text-base sm:text-lg font-black flex items-center justify-center gap-2 shadow-md cursor-pointer transition-colors"
                  >
                    <span>Next: Choose Your Work</span>
                    <ArrowRight className="w-5 h-5" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: Choose Your Work / Occupation */}
            {step === 2 && (
              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg sm:text-2xl font-black text-slate-900">
                    Step 2: What is your primary work?
                  </h2>
                  <button
                    onClick={() => speak('Step 2: Choose what kind of work you or your family does.', 'step2-audio')}
                    className="px-3 py-1.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer hover:bg-amber-200"
                  >
                    {activeSpeech === 'step2-audio' ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                    <span>Listen</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {occupations.map((occ) => (
                    <button
                      key={occ.id}
                      onClick={() => {
                        setSelectedOccupation(occ.id);
                        setStep(3);
                      }}
                      className={`p-4 rounded-2xl border-2 text-left font-bold text-sm sm:text-base flex items-center justify-between transition-all cursor-pointer ${
                        selectedOccupation === occ.id
                          ? 'bg-indigo-100 text-indigo-950 border-indigo-700 ring-2 ring-indigo-300'
                          : 'bg-slate-50 text-slate-800 border-slate-300 hover:bg-amber-100/60'
                      }`}
                    >
                      <span>{occ.label}</span>
                      <ArrowRight className="w-4 h-4 text-slate-400" />
                    </button>
                  ))}
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    onClick={() => setStep(1)}
                    className="w-1/3 py-3.5 rounded-2xl border-2 border-slate-300 font-bold text-slate-700 hover:bg-slate-100 cursor-pointer transition-colors"
                  >
                    Back
                  </button>
                  <button
                    onClick={() => setStep(3)}
                    className="w-2/3 py-3.5 rounded-2xl bg-indigo-600 text-white font-black hover:bg-indigo-700 shadow-md cursor-pointer transition-colors"
                  >
                    Next: Family Income
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Income level */}
            {step === 3 && (
              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg sm:text-2xl font-black text-slate-900">
                    Step 3: Approximate Family Income
                  </h2>
                  <button
                    onClick={() => speak('Step 3: Choose your family income level or select any income.', 'step3-audio')}
                    className="px-3 py-1.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer hover:bg-amber-200"
                  >
                    {activeSpeech === 'step3-audio' ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                    <span>Listen</span>
                  </button>
                </div>

                <div className="space-y-3">
                  {incomes.map((inc) => (
                    <button
                      key={inc.id}
                      onClick={() => {
                        setSelectedIncome(inc.id);
                        setStep(4);
                      }}
                      className={`w-full p-4 rounded-2xl border-2 text-left font-bold text-sm sm:text-base flex items-center justify-between transition-all cursor-pointer ${
                        selectedIncome === inc.id
                          ? 'bg-indigo-100 text-indigo-950 border-indigo-700 ring-2 ring-indigo-300'
                          : 'bg-slate-50 text-slate-800 border-slate-300 hover:bg-amber-100/60'
                      }`}
                    >
                      <div>
                        <div className="text-slate-900 font-bold">{inc.label}</div>
                        <div className="text-xs text-slate-500 font-normal">{inc.desc}</div>
                      </div>
                      <CheckCircle className="w-5 h-5 text-indigo-700 shrink-0" />
                    </button>
                  ))}
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    onClick={() => setStep(2)}
                    className="w-1/3 py-3.5 rounded-2xl border-2 border-slate-300 font-bold text-slate-700 hover:bg-slate-100 cursor-pointer transition-colors"
                  >
                    Back
                  </button>
                  <button
                    onClick={() => setStep(4)}
                    className="w-2/3 py-3.5 rounded-2xl bg-indigo-600 text-white font-black hover:bg-indigo-700 shadow-md cursor-pointer transition-colors"
                  >
                    Show My Schemes
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          /* Step 4: Simple Results Display */
          <div className="space-y-6">
            <div className="bg-white p-5 sm:p-6 rounded-3xl border-2 border-slate-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-xs uppercase tracking-wider">
                    {filteredSchemes.length} Schemes Matched
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
                  Your Personalized Scheme List
                </h2>
                <p className="text-xs font-semibold text-slate-500 mt-0.5">
                  Location: <span className="text-slate-800">{selectedState}</span> | Work: <span className="text-slate-800">{selectedOccupation ? selectedOccupation.replace(/_/g, ' ') : 'All'}</span>
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleResetFilters}
                  className="px-4 py-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs border border-slate-300 flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Change Answers</span>
                </button>
                {onOpenQuestionnaire && (
                  <button
                    onClick={onOpenQuestionnaire}
                    className="px-4 py-2 rounded-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-indigo-200" />
                    <span>Detailed Check</span>
                  </button>
                )}
              </div>
            </div>

            {/* Scheme Cards in Simple View or Empty State */}
            {filteredSchemes.length === 0 ? (
              <div className="bg-white rounded-3xl border-2 border-slate-300 p-8 sm:p-12 text-center space-y-4 shadow-md max-w-lg mx-auto">
                <div className="w-16 h-16 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center mx-auto text-2xl font-black">
                  🔍
                </div>
                <h3 className="text-lg sm:text-xl font-black text-slate-900">
                  No strict matches found for this specific filter
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  Try broadening your location to "All India" or exploring all {schemes.length} verified government welfare schemes in our catalog.
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                  <button
                    onClick={handleResetFilters}
                    className="w-full sm:w-auto px-5 py-2.5 rounded-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm shadow-md cursor-pointer transition-colors"
                  >
                    Reset Answers & Try Again
                  </button>
                  {onNavigate && (
                    <button
                      onClick={() => onNavigate('browse')}
                      className="w-full sm:w-auto px-5 py-2.5 rounded-full border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold text-xs sm:text-sm cursor-pointer transition-colors"
                    >
                      Browse All Schemes
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredSchemes.map((scheme) => {
                  const saved = isSaved(scheme.id);
                  const descText = language === 'hi' && scheme.description_hi
                    ? scheme.description_hi
                    : language === 'as' && scheme.description_as
                    ? scheme.description_as
                    : scheme.description;
                  const nameText = language === 'hi' && scheme.name_hi
                    ? scheme.name_hi
                    : language === 'as' && scheme.name_as
                    ? scheme.name_as
                    : scheme.name;

                  return (
                    <div
                      key={scheme.id}
                      className="bg-white rounded-3xl border-2 border-slate-300 p-6 space-y-4 hover:border-indigo-600 transition-all shadow-md"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-black uppercase tracking-wider bg-indigo-50 text-indigo-900 px-3 py-1 rounded-full border border-indigo-200">
                              {scheme.category.replace(/_/g, ' ')}
                            </span>
                            <span className="text-xs font-semibold text-slate-500">
                              {scheme.state}
                            </span>
                          </div>
                          <h3 className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
                            {nameText}
                          </h3>
                          <p className="text-xs font-bold text-slate-500 mt-0.5">
                            {scheme.department}
                          </p>
                        </div>

                        <button
                          onClick={() => speak(`${nameText}. ${descText}. Benefit: ${scheme.benefits}`, scheme.id)}
                          className={`p-3 rounded-2xl border-2 font-black text-xs flex items-center gap-1.5 shrink-0 cursor-pointer transition-colors ${
                            activeSpeech === scheme.id
                              ? 'bg-amber-300 text-slate-950 border-amber-500 animate-pulse'
                              : 'bg-amber-100 text-amber-950 border-amber-300 hover:bg-amber-200'
                          }`}
                          title="Listen to Scheme Summary"
                        >
                          {activeSpeech === scheme.id ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                          <span className="hidden sm:inline">Listen</span>
                        </button>
                      </div>

                      <p className="text-base text-slate-700 leading-relaxed font-medium">
                        {descText}
                      </p>

                      {scheme.benefits_amount && (
                        <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-950 font-bold text-sm">
                          💰 Benefit Amount: {scheme.benefits_amount}
                        </div>
                      )}

                      <div className="pt-2 flex flex-col sm:flex-row gap-3">
                        <button
                          onClick={() => onViewDetails(scheme)}
                          className="flex-1 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-base flex items-center justify-center gap-2 shadow-md cursor-pointer transition-colors"
                        >
                          <span>View Details & Documents</span>
                          <ArrowRight className="w-5 h-5" />
                        </button>

                        <button
                          onClick={() => {
                            if (saved) removeSavedScheme(scheme.id);
                            else saveScheme(scheme);
                          }}
                          className={`py-3.5 px-6 rounded-2xl border-2 font-black text-sm flex items-center justify-center gap-2 cursor-pointer transition-colors ${
                            saved
                              ? 'bg-indigo-50 text-indigo-900 border-indigo-300'
                              : 'bg-slate-100 text-slate-800 border-slate-300 hover:bg-slate-200'
                          }`}
                        >
                          <Bookmark className={`w-4 h-4 ${saved ? 'fill-indigo-700 text-indigo-700' : ''}`} />
                          <span>{saved ? 'Saved' : 'Save'}</span>
                        </button>

                        <a
                          href={scheme.official_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="py-3.5 px-4 rounded-2xl border border-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-slate-50 cursor-pointer"
                          title="Open official portal"
                        >
                          <ExternalLink className="w-4 h-4" />
                          <span>Portal</span>
                        </a>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
