import React, { useState } from 'react';
import {
  Bookmark,
  Bell,
  CheckCircle2,
  Calendar,
  ExternalLink,
  Trash2,
  Sparkles,
  FileText,
  AlertCircle,
  Plus,
  Clock
} from 'lucide-react';
import { Scheme } from '../../types/scheme';
import { useSavedSchemes } from '../../hooks/useSavedSchemes';
import { useLanguage } from '../../hooks/useLanguage';
import { SchemeCard } from '../schemes/SchemeCard';

interface UserDashboardProps {
  onViewDetails: (scheme: Scheme) => void;
  onOpenQuestionnaire: () => void;
  initialTab?: 'saved' | 'reminders';
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  onViewDetails,
  onOpenQuestionnaire,
  initialTab = 'saved'
}) => {
  const { t } = useLanguage();
  const { savedSchemes, removeSavedScheme, toggleReminderCompleted, saveScheme } = useSavedSchemes();
  const [activeTab, setActiveTab] = useState<'saved' | 'reminders' | 'checklist'>(initialTab);

  const schemesWithReminders = savedSchemes.filter((s) => s.reminder_date);
  const pendingReminders = schemesWithReminders.filter((s) => !s.reminder_completed);

  // Consolidated documents checklist across all saved schemes
  const allRequiredDocs = Array.from(
    new Set(savedSchemes.flatMap((s) => s.scheme.documents || []))
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner */}
      <div className="bg-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border border-slate-800">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-3 py-1 rounded-full flex items-center gap-1.5">
              <Bookmark className="w-3.5 h-3.5 text-indigo-400" />
              <span>Personal Scheme Organizer</span>
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
            {t.saved_schemes.title}
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
            {t.saved_schemes.subtitle}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenQuestionnaire}
            className="px-6 py-2.5 rounded-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg transition-all cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-indigo-200" />
            <span>Find More Schemes</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-3 border-b border-slate-200">
        <button
          onClick={() => setActiveTab('saved')}
          className={`pb-3.5 px-4 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'saved'
              ? 'text-indigo-600 border-indigo-600'
              : 'text-slate-500 border-transparent hover:text-slate-800'
          }`}
        >
          <Bookmark className="w-4 h-4" />
          <span>Saved Schemes ({savedSchemes.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('reminders')}
          className={`pb-3.5 px-4 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'reminders'
              ? 'text-indigo-600 border-indigo-600'
              : 'text-slate-500 border-transparent hover:text-slate-800'
          }`}
        >
          <Bell className="w-4 h-4" />
          <span>Application Reminders ({schemesWithReminders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('checklist')}
          className={`pb-3.5 px-4 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'checklist'
              ? 'text-indigo-600 border-indigo-600'
              : 'text-slate-500 border-transparent hover:text-slate-800'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Master Document Checklist ({allRequiredDocs.length})</span>
        </button>
      </div>

      {/* TAB 1: SAVED SCHEMES */}
      {activeTab === 'saved' && (
        <div>
          {savedSchemes.length === 0 ? (
            <div className="bg-white rounded-3xl border border-slate-200/80 p-12 text-center space-y-4 max-w-lg mx-auto shadow-xs">
              <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <Bookmark className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">
                {t.saved_schemes.no_saved}
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Bookmark schemes as you browse to track their deadlines, required documents, and official application portals.
              </p>
              <button
                onClick={onOpenQuestionnaire}
                className="px-6 py-2.5 rounded-full bg-indigo-600 text-white font-bold text-xs sm:text-sm hover:bg-indigo-700 shadow-md cursor-pointer transition-colors"
              >
                Run Eligibility Questionnaire
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {savedSchemes.map((item) => (
                <div key={item.scheme.id} className="relative">
                  <SchemeCard
                    scheme={item.scheme}
                    onViewDetails={onViewDetails}
                  />
                  {item.reminder_date && (
                    <div className="mt-2 p-3 bg-amber-50 rounded-2xl border border-amber-200 text-xs text-amber-900 flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Bell className="w-3.5 h-3.5 text-amber-700" />
                        <span>Reminder: <strong>{item.reminder_date}</strong></span>
                      </div>
                      {item.reminder_note && (
                        <span className="text-[11px] text-slate-500 truncate max-w-[120px]">
                          "{item.reminder_note}"
                        </span>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: REMINDERS */}
      {activeTab === 'reminders' && (
        <div className="space-y-4 max-w-3xl mx-auto">
          {schemesWithReminders.length === 0 ? (
            <div className="bg-white rounded-3xl border border-slate-200/80 p-10 text-center space-y-3 shadow-xs">
              <Clock className="w-12 h-12 text-slate-300 mx-auto" />
              <h3 className="text-base font-bold text-slate-800">
                {t.saved_schemes.no_reminders}
              </h3>
              <p className="text-xs text-slate-500">
                When viewing any scheme details, click "Set Reminder" to schedule application date notifications.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {schemesWithReminders.map((item) => (
                <div
                  key={item.scheme.id}
                  className={`p-5 rounded-3xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                    item.reminder_completed
                      ? 'bg-slate-50 border-slate-200 opacity-60'
                      : 'bg-white border-slate-200 shadow-xs'
                  }`}
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-indigo-800 bg-indigo-50 px-3 py-0.5 rounded-full border border-indigo-100">
                        {item.scheme.category}
                      </span>
                      <span className="text-xs font-semibold text-amber-900 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200/60 flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-amber-700" />
                        <span>Due: {item.reminder_date}</span>
                      </span>
                    </div>

                    <h4 className="text-base font-bold text-slate-900">
                      {item.scheme.name}
                    </h4>

                    {item.reminder_note && (
                      <p className="text-xs text-slate-600 italic">
                        Note: {item.reminder_note}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    <button
                      onClick={() => toggleReminderCompleted(item.scheme.id)}
                      className={`px-4 py-1.5 rounded-full text-xs font-bold transition-colors cursor-pointer ${
                        item.reminder_completed
                          ? 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                          : 'bg-indigo-600 text-white hover:bg-indigo-700'
                      }`}
                    >
                      {item.reminder_completed ? 'Mark Pending' : 'Mark Completed'}
                    </button>

                    <button
                      onClick={() => onViewDetails(item.scheme)}
                      className="px-4 py-1.5 rounded-full border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer transition-colors"
                    >
                      View
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: MASTER DOCUMENT CHECKLIST */}
      {activeTab === 'checklist' && (
        <div className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 space-y-6 max-w-3xl mx-auto shadow-xs">
          <div>
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <FileText className="w-5 h-5 text-indigo-600" />
              <span>Consolidated Application Documents Checklist</span>
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Documents required across your {savedSchemes.length} saved government schemes. Prepare these in advance:
            </p>
          </div>

          {allRequiredDocs.length === 0 ? (
            <p className="text-xs text-slate-400">Save schemes to see their document checklist.</p>
          ) : (
            <div className="space-y-2.5">
              {allRequiredDocs.map((doc, idx) => (
                <label
                  key={idx}
                  className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-50 hover:bg-indigo-50/40 border border-slate-200/70 transition-colors cursor-pointer"
                >
                  <input
                    type="checkbox"
                    className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-600 mt-0.5"
                  />
                  <div className="text-xs sm:text-sm font-medium text-slate-800 leading-snug">
                    {doc}
                  </div>
                </label>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
