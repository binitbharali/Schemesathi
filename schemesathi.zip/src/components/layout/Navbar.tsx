import React, { useState } from 'react';
import {
  Compass,
  Bookmark,
  Languages,
  ShieldCheck,
  Menu,
  X,
  Search,
  Sparkles,
  Bot,
  UserCheck,
  Bell,
  Eye
} from 'lucide-react';
import { useLanguage } from '../../hooks/useLanguage';
import { useSimpleMode } from '../../hooks/useSimpleMode';
import { useSavedSchemes } from '../../hooks/useSavedSchemes';
import { useAuth } from '../../hooks/useAuth';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onOpenQuestionnaire: () => void;
  onOpenAssistant: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onOpenQuestionnaire,
  onOpenAssistant
}) => {
  const { language, setLanguage, t, supportedLanguages } = useLanguage();
  const { isSimpleMode, toggleSimpleMode } = useSimpleMode();
  const { savedSchemes } = useSavedSchemes();
  const { user, isAdmin, loginAsAdmin, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showLanguageDropdown, setShowLanguageDropdown] = useState(false);
  const [showAdminDropdown, setShowAdminDropdown] = useState(false);

  const pendingRemindersCount = savedSchemes.filter(
    (s) => s.reminder_date && !s.reminder_completed
  ).length;

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Brand Identity */}
          <div
            className="flex items-center gap-3 cursor-pointer select-none"
            onClick={() => onNavigate('home')}
          >
            <div className="w-10 h-10 bg-indigo-700 rounded-xl flex items-center justify-center text-white font-black text-xl shadow-xs">
              S
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-extrabold tracking-tight text-indigo-950">
                  Scheme<span className="text-indigo-600">Sathi</span>
                </span>
                <span className="text-[10px] font-bold tracking-wider uppercase bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full border border-indigo-100">
                  SIH 2026
                </span>
              </div>
              <p className="text-[11px] text-slate-500 hidden sm:block leading-none mt-0.5">
                {t.tagline}
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            <button
              id="nav-home-btn"
              onClick={() => onNavigate('home')}
              className={`transition-colors py-1 ${
                currentView === 'home'
                  ? 'text-indigo-700 font-bold border-b-2 border-indigo-700 pb-1'
                  : 'text-slate-500 hover:text-indigo-700'
              }`}
            >
              {t.nav.home}
            </button>

            <button
              id="nav-browse-btn"
              onClick={() => onNavigate('browse')}
              className={`transition-colors py-1 flex items-center gap-1.5 ${
                currentView === 'browse'
                  ? 'text-indigo-700 font-bold border-b-2 border-indigo-700 pb-1'
                  : 'text-slate-500 hover:text-indigo-700'
              }`}
            >
              <Search className="w-4 h-4 text-slate-400" />
              <span>{t.nav.browse}</span>
            </button>

            <button
              id="nav-saved-btn"
              onClick={() => onNavigate('saved')}
              className={`transition-colors py-1 flex items-center gap-1.5 ${
                currentView === 'saved'
                  ? 'text-indigo-700 font-bold border-b-2 border-indigo-700 pb-1'
                  : 'text-slate-500 hover:text-indigo-700'
              }`}
            >
              <Bookmark className="w-4 h-4 text-slate-400" />
              <span>{t.nav.saved}</span>
              {savedSchemes.length > 0 && (
                <span className="inline-flex items-center px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-indigo-100 text-indigo-800">
                  {savedSchemes.length}
                </span>
              )}
            </button>

            <button
              id="nav-reminders-btn"
              onClick={() => onNavigate('reminders')}
              className={`transition-colors py-1 flex items-center gap-1.5 ${
                currentView === 'reminders'
                  ? 'text-indigo-700 font-bold border-b-2 border-indigo-700 pb-1'
                  : 'text-slate-500 hover:text-indigo-700'
              }`}
            >
              <Bell className="w-4 h-4 text-slate-400" />
              <span>{t.nav.reminders}</span>
              {pendingRemindersCount > 0 && (
                <span className="inline-flex items-center px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-amber-500 text-white">
                  {pendingRemindersCount}
                </span>
              )}
            </button>

            <button
              id="nav-assistant-btn"
              onClick={onOpenAssistant}
              className="px-3 py-1.5 rounded-full text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 transition-colors flex items-center gap-1.5 border border-indigo-200"
              title="Ask Grounded Scheme Assistant"
            >
              <Bot className="w-3.5 h-3.5 text-indigo-600" />
              <span>AI Help</span>
            </button>
          </nav>

          {/* Right Action Controls */}
          <div className="flex items-center gap-3">
            <div className="h-6 w-px bg-slate-200 hidden sm:block"></div>

            {/* Language Selector Pill */}
            <div className="relative">
              <button
                id="language-selector-btn"
                onClick={() => setShowLanguageDropdown(!showLanguageDropdown)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-slate-300 hover:bg-slate-50 text-slate-700 transition-colors"
                aria-expanded={showLanguageDropdown}
              >
                <span className="text-xs uppercase tracking-wider font-bold">
                  {language === 'en' ? 'EN' : language === 'hi' ? 'HI' : 'AS'}
                </span>
                <span className="text-slate-300">|</span>
                <span className="text-xs font-medium text-slate-500">
                  {language === 'en' ? 'हिंदी' : language === 'hi' ? 'Eng' : 'অসম'}
                </span>
              </button>

              {showLanguageDropdown && (
                <div className="absolute right-0 mt-2 w-40 bg-white rounded-2xl shadow-xl border border-slate-100 py-2 z-50 animate-in fade-in duration-100">
                  <div className="px-3.5 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    {t.nav.language}
                  </div>
                  {supportedLanguages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setLanguage(lang.code);
                        setShowLanguageDropdown(false);
                      }}
                      className={`w-full text-left px-3.5 py-2 text-xs flex items-center justify-between transition-colors ${
                        language === lang.code
                          ? 'bg-indigo-50 text-indigo-900 font-bold'
                          : 'text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <span>{lang.nativeName}</span>
                      <span className="text-[10px] text-slate-400 uppercase font-bold">{lang.code}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Simple Mode Toggle Pill */}
            <button
              id="toggle-simple-mode-btn"
              onClick={toggleSimpleMode}
              aria-label="Toggle Simple Mode"
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold uppercase tracking-wide transition-all ${
                isSimpleMode
                  ? 'bg-amber-400 text-slate-950 shadow-xs ring-2 ring-amber-300'
                  : 'bg-amber-100 text-amber-900 hover:bg-amber-200'
              }`}
              title="Low digital literacy accessible view"
            >
              <span>✨</span>
              <span className="hidden sm:inline">
                {isSimpleMode ? t.nav.standard_mode : t.nav.simple_mode}
              </span>
            </button>

            {/* Primary Action Button */}
            <button
              id="nav-find-btn"
              onClick={onOpenQuestionnaire}
              className="px-5 py-2 bg-indigo-600 text-white text-xs sm:text-sm font-bold rounded-full hover:bg-indigo-700 shadow-sm transition-all flex items-center gap-1.5"
            >
              <Sparkles className="w-4 h-4 text-indigo-200" />
              <span>{t.nav.find_schemes}</span>
            </button>

            {/* Admin / Evaluator Quick Access */}
            <div className="relative">
              <button
                id="admin-menu-btn"
                onClick={() => setShowAdminDropdown(!showAdminDropdown)}
                className={`p-2 rounded-full border text-xs font-medium flex items-center gap-1 transition-colors ${
                  isAdmin
                    ? 'bg-purple-100 text-purple-900 border-purple-300'
                    : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                }`}
                title="Admin / SIH Evaluator Portal"
              >
                <ShieldCheck className="w-4 h-4 text-indigo-700" />
              </button>

              {showAdminDropdown && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-100 p-2.5 z-50">
                  <div className="px-2 py-1 border-b border-slate-100 mb-1.5">
                    <p className="text-xs font-bold text-slate-900">
                      {isAdmin ? 'Nodal Officer Portal' : 'SIH 2026 Admin Access'}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      {isAdmin ? 'Logged in as Department Admin' : 'Simulate Nodal Officer view'}
                    </p>
                  </div>

                  {isAdmin ? (
                    <>
                      <button
                        onClick={() => {
                          onNavigate('admin');
                          setShowAdminDropdown(false);
                        }}
                        className="w-full text-left px-3 py-2 text-xs text-indigo-900 bg-indigo-50 hover:bg-indigo-100 rounded-xl font-semibold mb-1 flex items-center gap-2"
                      >
                        <ShieldCheck className="w-4 h-4 text-indigo-700" />
                        <span>Open Admin Dashboard</span>
                      </button>
                      <button
                        onClick={() => {
                          logout();
                          setShowAdminDropdown(false);
                        }}
                        className="w-full text-left px-3 py-2 text-xs text-rose-600 hover:bg-rose-50 rounded-xl font-medium"
                      >
                        {t.nav.logout}
                      </button>
                    </>
                  ) : (
                    <button
                      id="sih-quick-admin-login-btn"
                      onClick={() => {
                        loginAsAdmin();
                        setShowAdminDropdown(false);
                        onNavigate('admin');
                      }}
                      className="w-full text-left px-3 py-2.5 text-xs text-indigo-950 bg-indigo-50 hover:bg-indigo-100 rounded-xl font-bold flex items-center gap-2"
                    >
                      <UserCheck className="w-4 h-4 text-indigo-700" />
                      <span>Login as Admin (Evaluator)</span>
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Mobile menu toggle button */}
            <div className="flex md:hidden">
              <button
                id="mobile-menu-toggle-btn"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-xl text-slate-700 hover:bg-slate-100 focus:outline-hidden"
                aria-label="Toggle menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile navigation drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-5 space-y-1.5 shadow-lg animate-in slide-in-from-top-2">
          <button
            onClick={() => {
              onNavigate('home');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 rounded-xl text-sm font-semibold text-slate-800 hover:bg-slate-50"
          >
            {t.nav.home}
          </button>
          <button
            onClick={() => {
              onOpenQuestionnaire();
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-4 py-2.5 rounded-full text-sm font-bold bg-indigo-600 text-white flex items-center gap-2 shadow-sm"
          >
            <Sparkles className="w-4 h-4 text-indigo-200" />
            <span>{t.nav.find_schemes}</span>
          </button>
          <button
            onClick={() => {
              onNavigate('browse');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 rounded-xl text-sm font-medium text-slate-800 hover:bg-slate-50"
          >
            {t.nav.browse}
          </button>
          <button
            onClick={() => {
              onNavigate('saved');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 rounded-xl text-sm font-medium text-slate-800 hover:bg-slate-50 flex items-center justify-between"
          >
            <span>{t.nav.saved}</span>
            {savedSchemes.length > 0 && (
              <span className="px-2 py-0.5 text-xs rounded-full bg-indigo-100 text-indigo-800 font-bold">
                {savedSchemes.length}
              </span>
            )}
          </button>
          <button
            onClick={() => {
              onNavigate('reminders');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 rounded-xl text-sm font-medium text-slate-800 hover:bg-slate-50 flex items-center justify-between"
          >
            <span>{t.nav.reminders}</span>
            {pendingRemindersCount > 0 && (
              <span className="px-2 py-0.5 text-xs rounded-full bg-amber-500 text-white font-bold">
                {pendingRemindersCount}
              </span>
            )}
          </button>
          <button
            onClick={() => {
              onOpenAssistant();
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 rounded-xl text-sm font-medium text-indigo-800 bg-indigo-50 flex items-center gap-2"
          >
            <Bot className="w-4 h-4 text-indigo-600" />
            <span>AI Scheme Assistant</span>
          </button>
        </div>
      )}
    </header>
  );
};
