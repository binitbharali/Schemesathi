import React from 'react';
import { Info } from 'lucide-react';
import { useLanguage } from '../../hooks/useLanguage';

export const DisclaimerBanner: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div
      id="scheme-disclaimer-banner"
      className="bg-amber-50/90 border-b border-amber-200/80 px-4 py-2 text-xs text-amber-900"
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Info className="w-4 h-4 text-amber-700 shrink-0" aria-hidden="true" />
          <p className="leading-snug">
            <span className="font-semibold">Informational Platform Notice:</span> {t.official_disclaimer}
          </p>
        </div>
      </div>
    </div>
  );
};
