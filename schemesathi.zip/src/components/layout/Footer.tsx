import React from 'react';
import { Compass, ShieldCheck, Heart, ExternalLink, Globe } from 'lucide-react';
import { useLanguage } from '../../hooks/useLanguage';

interface FooterProps {
  onNavigate: (view: string) => void;
  onOpenQuestionnaire: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenQuestionnaire }) => {
  const { t } = useLanguage();

  return (
    <footer className="bg-white text-slate-600 border-t border-slate-200 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Brand & Purpose */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-indigo-700 flex items-center justify-center text-white font-black text-lg shadow-2xs">
                S
              </div>
              <span className="text-xl font-extrabold text-slate-900 tracking-tight">
                Scheme<span className="text-indigo-600">Sathi</span>
              </span>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              An accessible, privacy-respecting government scheme navigator designed for Smart India Hackathon (SIH) 2026. Empowering citizens across India to discover public welfare benefits.
            </p>
            <div className="flex items-center gap-2 text-xs text-indigo-700 font-bold">
              <ShieldCheck className="w-4 h-4 text-indigo-600" />
              <span>Grounded on Official Government Sources</span>
            </div>
          </div>

          {/* Quick Navigation */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4">
              Quick Navigation
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-500">
              <li>
                <button
                  onClick={() => onNavigate('home')}
                  className="hover:text-indigo-700 font-medium transition-colors cursor-pointer"
                >
                  {t.nav.home}
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenQuestionnaire}
                  className="text-indigo-600 font-bold hover:underline cursor-pointer"
                >
                  {t.nav.find_schemes}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('browse')}
                  className="hover:text-indigo-700 font-medium transition-colors cursor-pointer"
                >
                  {t.nav.browse}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('saved')}
                  className="hover:text-indigo-700 font-medium transition-colors cursor-pointer"
                >
                  {t.nav.saved}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('reminders')}
                  className="hover:text-indigo-700 font-medium transition-colors cursor-pointer"
                >
                  {t.nav.reminders}
                </button>
              </li>
            </ul>
          </div>

          {/* Official Government Portals */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4">
              Official Government Portals
            </h4>
            <ul className="space-y-2 text-xs text-slate-500">
              <li>
                <a
                  href="https://www.myscheme.gov.in"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-indigo-700 flex items-center gap-1.5 transition-colors"
                >
                  <Globe className="w-3.5 h-3.5 text-slate-400" />
                  <span>myScheme Portal (Gov of India)</span>
                  <ExternalLink className="w-2.5 h-2.5 text-slate-400" />
                </a>
              </li>
              <li>
                <a
                  href="https://scholarships.gov.in"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-indigo-700 flex items-center gap-1.5 transition-colors"
                >
                  <Globe className="w-3.5 h-3.5 text-slate-400" />
                  <span>National Scholarship Portal</span>
                  <ExternalLink className="w-2.5 h-2.5 text-slate-400" />
                </a>
              </li>
              <li>
                <a
                  href="https://pmkisan.gov.in"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-indigo-700 flex items-center gap-1.5 transition-colors"
                >
                  <Globe className="w-3.5 h-3.5 text-slate-400" />
                  <span>PM-KISAN Portal</span>
                  <ExternalLink className="w-2.5 h-2.5 text-slate-400" />
                </a>
              </li>
              <li>
                <a
                  href="https://beneficiary.nha.gov.in"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-indigo-700 flex items-center gap-1.5 transition-colors"
                >
                  <Globe className="w-3.5 h-3.5 text-slate-400" />
                  <span>Ayushman Bharat (PM-JAY)</span>
                  <ExternalLink className="w-2.5 h-2.5 text-slate-400" />
                </a>
              </li>
              <li>
                <a
                  href="https://www.swavlambancard.gov.in"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-indigo-700 flex items-center gap-1.5 transition-colors"
                >
                  <Globe className="w-3.5 h-3.5 text-slate-400" />
                  <span>UDID Divyangjan Portal</span>
                  <ExternalLink className="w-2.5 h-2.5 text-slate-400" />
                </a>
              </li>
            </ul>
          </div>

          {/* Privacy & Trust Pledge */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4">
              Data Privacy & Safety
            </h4>
            <p className="text-xs text-slate-500 leading-relaxed mb-3">
              We uphold strict data minimization:
            </p>
            <ul className="space-y-1.5 text-xs font-medium text-slate-600">
              <li className="flex items-center gap-1.5 text-indigo-700">
                <span>✓</span> Zero Aadhaar storage
              </li>
              <li className="flex items-center gap-1.5 text-indigo-700">
                <span>✓</span> No OTP or bank credentials
              </li>
              <li className="flex items-center gap-1.5 text-indigo-700">
                <span>✓</span> Transparent rule matching
              </li>
            </ul>
          </div>
        </div>

        {/* Legal Disclaimer Box */}
        <div className="bg-amber-50/70 rounded-2xl p-4 border border-amber-200/80 mb-8">
          <p className="text-xs text-amber-950 leading-relaxed">
            <span className="font-bold text-amber-900">Important Disclaimer:</span> {t.official_disclaimer}
          </p>
        </div>

        {/* Bottom Credits with Minimalist Status */}
        <div className="pt-6 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-4">
          <div className="flex items-center gap-2">
            <span>© {new Date().getFullYear()} SchemeSathi. Built for SIH 2026.</span>
            <span className="text-slate-300">•</span>
            <span className="text-emerald-600 font-semibold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
              Live Official Rules
            </span>
          </div>
          <div className="flex items-center gap-4">
            <span className="inline-flex items-center gap-1 text-slate-500 font-medium">
              Made with <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" /> for Indian Citizens
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
