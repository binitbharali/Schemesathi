import React, { useState } from 'react';
import { PlayCircle, CheckCircle2, ChevronRight, X, Sparkles, ShieldCheck } from 'lucide-react';
import { QuestionnaireAnswers } from '../../types';

interface DemoFlowBannerProps {
  onLoadPreset: (preset: QuestionnaireAnswers, presetName: string) => void;
  onOpenAdmin: () => void;
  onOpenSimpleMode: () => void;
}

export const DemoFlowBanner: React.FC<DemoFlowBannerProps> = ({
  onLoadPreset,
  onOpenAdmin,
  onOpenSimpleMode
}) => {
  const [isOpen, setIsOpen] = useState(true);

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 z-30 bg-indigo-950 text-white text-xs font-bold px-4 py-2 rounded-full shadow-lg border border-indigo-800 flex items-center gap-2 hover:bg-indigo-900 transition-all hover:scale-105 cursor-pointer"
      >
        <Sparkles className="w-3.5 h-3.5 text-amber-300" />
        <span>SIH 2026 Demo Presets</span>
      </button>
    );
  }

  const presets = [
    {
      name: 'College Student (Assam)',
      desc: 'Matches Pragyan Bharati Fee Waiver + Post-Matric Scholarship',
      data: {
        age: 20,
        gender: 'male',
        state: 'Assam',
        district: 'Kamrup Metropolitan (Guwahati)',
        areaType: 'urban',
        occupation: 'student',
        incomeBracket: '1_to_2_5_lakh',
        hasBplOrRationCard: false,
        studentLevel: 'undergraduate',
        farmerCategory: 'not_applicable',
        hasDisability: false,
        socialCategory: 'obc',
        housingType: 'pucca'
      } as QuestionnaireAnswers
    },
    {
      name: 'Small Farmer (All India)',
      desc: 'Matches PM-KISAN Samman Nidhi + Ayushman Bharat',
      data: {
        age: 42,
        gender: 'male',
        state: 'Uttar Pradesh',
        district: 'Varanasi',
        areaType: 'rural',
        occupation: 'farmer',
        incomeBracket: 'below_1_lakh',
        hasBplOrRationCard: true,
        studentLevel: 'not_applicable',
        farmerCategory: 'small',
        hasDisability: false,
        socialCategory: 'general',
        housingType: 'kutcha'
      } as QuestionnaireAnswers
    },
    {
      name: 'Senior Citizen (BPL)',
      desc: 'Matches IGNOAPS Old Age Pension + Ayushman Bharat',
      data: {
        age: 64,
        gender: 'female',
        state: 'Maharashtra',
        district: 'Nagpur',
        areaType: 'rural',
        occupation: 'retired_senior',
        incomeBracket: 'bpl_antyodaya',
        hasBplOrRationCard: true,
        studentLevel: 'not_applicable',
        farmerCategory: 'not_applicable',
        isSingleWomanOrWidow: true,
        hasDisability: false,
        socialCategory: 'sc',
        housingType: 'kutcha'
      } as QuestionnaireAnswers
    },
    {
      name: 'Divyangjan Artisan (MSME)',
      desc: 'Matches PM Vishwakarma + ADIP Assistive Device Support',
      data: {
        age: 32,
        gender: 'male',
        state: 'Bihar',
        district: 'Patna',
        areaType: 'rural',
        occupation: 'artisan_craftsperson',
        incomeBracket: '1_to_2_5_lakh',
        hasBplOrRationCard: false,
        hasDisability: true,
        disabilityPercentage: 50,
        socialCategory: 'obc',
        housingType: 'semi_pucca'
      } as QuestionnaireAnswers
    }
  ];

  return (
    <div className="bg-slate-900 text-white text-xs py-2 px-4 border-b border-slate-800">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-2.5">
        <div className="flex items-center gap-2">
          <span className="bg-indigo-600 text-white font-bold px-2 py-0.5 rounded-full text-[10px] uppercase tracking-wider">
            SIH Evaluator Quick-Test
          </span>
          <span className="text-slate-300 hidden sm:inline">
            Load sample test personas to verify rule-based matching instantly:
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {presets.map((preset) => (
            <button
              key={preset.name}
              onClick={() => onLoadPreset(preset.data, preset.name)}
              className="px-2.5 py-1 rounded-full bg-slate-800 hover:bg-indigo-600 hover:text-white transition-all text-slate-200 text-[11px] font-semibold border border-slate-700 flex items-center gap-1 cursor-pointer"
              title={preset.desc}
            >
              <PlayCircle className="w-3 h-3 text-indigo-400" />
              <span>{preset.name}</span>
            </button>
          ))}

          <button
            onClick={onOpenAdmin}
            className="px-2.5 py-1 rounded-full bg-indigo-900/80 hover:bg-indigo-800 text-indigo-200 text-[11px] font-semibold border border-indigo-700 flex items-center gap-1 cursor-pointer"
          >
            <ShieldCheck className="w-3 h-3 text-indigo-400" />
            <span>Admin</span>
          </button>

          <button
            onClick={() => setIsOpen(false)}
            className="p-1 text-slate-400 hover:text-white rounded cursor-pointer"
            aria-label="Close demo bar"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
