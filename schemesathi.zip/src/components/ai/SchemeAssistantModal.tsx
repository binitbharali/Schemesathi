import React, { useState } from 'react';
import {
  Bot,
  X,
  Send,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  HelpCircle,
  Building2,
  Mic,
  ArrowRight
} from 'lucide-react';
import { Scheme } from '../../types/scheme';
import { AiService, AiAssistantResponse } from '../../services/aiService';
import { useLanguage } from '../../hooks/useLanguage';
import { SchemeVoiceSearch } from '../schemes/SchemeVoiceSearch';

interface SchemeAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  schemes: Scheme[];
  onViewSchemeDetails: (scheme: Scheme) => void;
}

export const SchemeAssistantModal: React.FC<SchemeAssistantModalProps> = ({
  isOpen,
  onClose,
  schemes,
  onViewSchemeDetails
}) => {
  const { language } = useLanguage();
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<AiAssistantResponse | null>(null);
  const [showVoiceSearch, setShowVoiceSearch] = useState(false);

  if (!isOpen) return null;

  const handleAsk = async (userQuery?: string) => {
    const q = userQuery || query;
    if (!q.trim()) return;

    setLoading(true);
    setResponse(null);

    const res = await AiService.answerCitizenQuery(q, schemes, language);
    setResponse(res);
    setLoading(false);
  };

  const sampleQuestions = [
    'What schemes are available for college students in Assam?',
    'How do I get financial assistance as a small farmer with 2 acres?',
    'What is the benefit amount for Ayushman Bharat PM-JAY?',
    'Is there any scheme for street vendors or small shopkeepers?'
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-slate-900 text-white p-6 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center text-white shadow-xs">
              <Bot className="w-5 h-5 text-indigo-100" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-white tracking-tight">
                  SchemeSathi Grounded Assistant
                </h3>
                <span className="text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2.5 py-0.5 rounded-full">
                  Zero Hallucination
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Answers citizen questions strictly using verified database records.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chat / Query Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1 text-slate-800 text-sm">
          {/* Sample quick prompts if no response yet */}
          {!response && !loading && (
            <div className="space-y-3">
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Sample citizen questions to try:
              </p>
              <div className="space-y-2">
                {sampleQuestions.map((qText, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setQuery(qText);
                      handleAsk(qText);
                    }}
                    className="w-full text-left p-3.5 rounded-2xl bg-slate-50 hover:bg-indigo-50/60 border border-slate-200/80 hover:border-indigo-200 transition-all text-xs sm:text-sm font-medium text-slate-700 hover:text-indigo-950 flex items-center justify-between gap-2 cursor-pointer"
                  >
                    <span>{qText}</span>
                    <ArrowRight className="w-4 h-4 text-slate-400 shrink-0" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Loading state */}
          {loading && (
            <div className="py-12 text-center space-y-3">
              <div className="w-8 h-8 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-xs font-semibold text-slate-600">
                Searching verified government scheme database...
              </p>
            </div>
          )}

          {/* AI Grounded Response */}
          {response && !loading && (
            <div className="space-y-4 animate-in fade-in">
              <div className="p-5 bg-indigo-50/50 border border-indigo-100 rounded-3xl space-y-3">
                <div className="flex items-center gap-2 text-xs font-bold text-indigo-900">
                  <Sparkles className="w-4 h-4 text-indigo-600" />
                  <span>SchemeSathi Recommendation Analysis:</span>
                </div>
                <div className="text-xs sm:text-sm text-slate-800 leading-relaxed whitespace-pre-line">
                  {response.answer}
                </div>
              </div>

              {/* Matched Scheme Cards */}
              {response.matchedSchemes.length > 0 && (
                <div className="space-y-2.5">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Potentially Relevant Scheme Details:
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {response.matchedSchemes.map((s) => (
                      <div
                        key={s.id}
                        onClick={() => {
                          onViewSchemeDetails(s);
                          onClose();
                        }}
                        className="p-4 bg-white rounded-2xl border border-slate-200 hover:border-indigo-500 hover:shadow-md cursor-pointer transition-all space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold uppercase bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full">
                            {s.category}
                          </span>
                          <span className="text-[11px] text-slate-400 font-medium">
                            {s.state}
                          </span>
                        </div>
                        <h5 className="text-xs sm:text-sm font-bold text-slate-900 leading-snug">
                          {s.name}
                        </h5>
                        <p className="text-xs text-slate-500 line-clamp-2">
                          {s.benefits}
                        </p>
                        <div className="text-[11px] font-bold text-indigo-600 flex items-center gap-1 pt-1">
                          <span>View Full Criteria</span>
                          <ArrowRight className="w-3 h-3" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-[11px] text-slate-600 flex items-start gap-2">
                <HelpCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                <span>
                  Notice: Information is derived from official public sources. Final eligibility is determined exclusively by the respective government department.
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-4 bg-slate-50 border-t border-slate-200">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleAsk();
            }}
            className="flex items-center gap-2"
          >
            <button
              type="button"
              onClick={() => setShowVoiceSearch(true)}
              className="p-2.5 rounded-full border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 cursor-pointer transition-colors"
              title="Voice Query"
            >
              <Mic className="w-4 h-4 text-indigo-600" />
            </button>

            <input
              type="text"
              placeholder="Ask about any scheme, criteria, documents, or benefits..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="flex-1 px-4 py-2.5 bg-white border border-slate-200 rounded-full text-xs sm:text-sm font-medium text-slate-900 focus:ring-2 focus:ring-indigo-600 focus:outline-hidden"
            />

            <button
              type="submit"
              disabled={loading || !query.trim()}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-full font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-sm cursor-pointer transition-colors"
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline">Ask</span>
            </button>
          </form>
        </div>
      </div>

      <SchemeVoiceSearch
        isOpen={showVoiceSearch}
        onClose={() => setShowVoiceSearch(false)}
        onTranscript={(text) => {
          setQuery(text);
          handleAsk(text);
        }}
      />
    </div>
  );
};
