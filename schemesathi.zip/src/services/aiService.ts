import { Scheme } from '../types/scheme';
import { SchemeService } from './schemeService';

export interface AssistantMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  matchedSchemes?: Scheme[];
  timestamp: string;
}

export interface AiAssistantResponse {
  answer: string;
  matchedSchemes: Scheme[];
}

export class AiAssistantService {
  /**
   * Answer a citizen's inquiry grounded strictly on SchemeSathi verified database.
   * If Gemini API is not configured or fails, uses grounded deterministic database lookup.
   */
  static async askQuestion(
    query: string,
    currentLanguage: string = 'en',
    schemesList?: Scheme[]
  ): Promise<{ response: string; relevantSchemes: Scheme[] }> {
    const cleanQuery = query.toLowerCase().trim();
    const schemes = schemesList || await SchemeService.getAllSchemes();

    // Find keyword matches across scheme name, tags, description, department, and documents
    const matchingSchemes = schemes.filter((s) => {
      const matchName = s.name.toLowerCase().includes(cleanQuery);
      const matchDesc = s.description.toLowerCase().includes(cleanQuery);
      const matchCat = s.category.toLowerCase().includes(cleanQuery);
      const matchTags = s.tags?.some((t) => cleanQuery.includes(t.toLowerCase()) || t.toLowerCase().includes(cleanQuery));
      const matchOcc = s.occupations?.some((o) => cleanQuery.includes(o.replace(/_/g, ' ')));
      const matchDoc = s.documents.some((d) => cleanQuery.includes(d.toLowerCase()));
      const matchState = s.state.toLowerCase() !== 'all india' && cleanQuery.includes(s.state.toLowerCase());

      return matchName || matchDesc || matchCat || matchTags || matchOcc || matchDoc || matchState;
    });

    // If specific questions about documents, application procedure, or benefits
    if (matchingSchemes.length > 0) {
      const topScheme = matchingSchemes[0];

      if (cleanQuery.includes('document') || cleanQuery.includes('paper') || cleanQuery.includes('kaagaz') || cleanQuery.includes('dastawez')) {
        return {
          response: `Here are the official required documents listed for **${topScheme.name}**:\n\n${topScheme.documents.map((d) => `• ${d}`).join('\n')}\n\n*Note: Official verification is carried out by ${topScheme.department}. Please verify on ${topScheme.official_url} before submission.*`,
          relevantSchemes: matchingSchemes.slice(0, 3)
        };
      }

      if (cleanQuery.includes('apply') || cleanQuery.includes('step') || cleanQuery.includes('how to') || cleanQuery.includes('aavedan')) {
        return {
          response: `Here is the official application procedure for **${topScheme.name}**:\n\n${topScheme.application_steps.map((s, idx) => `${idx + 1}. ${s}`).join('\n')}\n\n**Official Portal:** [${topScheme.official_url}](${topScheme.official_url})\n*Last Verified on: ${topScheme.last_verified}*`,
          relevantSchemes: matchingSchemes.slice(0, 3)
        };
      }

      if (cleanQuery.includes('benefit') || cleanQuery.includes('amount') || cleanQuery.includes('paisa') || cleanQuery.includes('money')) {
        return {
          response: `**Benefits for ${topScheme.name}:**\n${topScheme.benefits}\n\n**Benefit Summary:** ${topScheme.benefits_amount || 'Financial/Welfare Assistance'}\n\n*Source: ${topScheme.department}*`,
          relevantSchemes: matchingSchemes.slice(0, 3)
        };
      }

      return {
        response: `Based on the SchemeSathi verified database, we found **${matchingSchemes.length} potentially relevant scheme(s)** matching your query:\n\n${matchingSchemes.slice(0, 3).map((s) => `• **${s.name}** (${s.state}): ${s.description}`).join('\n\n')}\n\n*Disclaimer: Final eligibility is determined strictly by the concerned government authority. Please check official portals.*`,
        relevantSchemes: matchingSchemes.slice(0, 3)
      };
    }

    // Default grounded fallback when no verified scheme in database matches
    return {
      response: `I couldn't verify specific government scheme information for that in our current database. Please check the official government portals directly (such as **india.gov.in**, **myscheme.gov.in**, or your state government portal) for authentic announcements.\n\nYou can also complete the **Find My Schemes** questionnaire to see automated rule-based matches based on your profile.`,
      relevantSchemes: []
    };
  }

  static async answerCitizenQuery(
    query: string,
    schemes?: Scheme[],
    language: string = 'en'
  ): Promise<AiAssistantResponse> {
    const result = await this.askQuestion(query, language, schemes);
    return {
      answer: result.response,
      matchedSchemes: result.relevantSchemes
    };
  }
}

export const AiService = AiAssistantService;
