import { Scheme, SavedScheme, VerificationStatus } from '../types/scheme';
import { INITIAL_SCHEMES } from '../data/schemesData';
import { supabase, isSupabaseConfigured } from './supabase';

const LOCAL_STORAGE_SCHEMES_KEY = 'schemesathi_schemes_v1';
const LOCAL_STORAGE_SAVED_KEY = 'schemesathi_saved_schemes_v1';

export class SchemeService {
  /**
   * Get all schemes from Supabase or Local Storage fallback
   */
  static async getAllSchemes(): Promise<Scheme[]> {
    if (isSupabaseConfigured && supabase) {
      try {
        const { data, error } = await supabase
          .from('schemes')
          .select('*')
          .order('created_at', { ascending: false });

        if (!error && data && data.length > 0) {
          return data as Scheme[];
        }
      } catch (err) {
        console.warn('Supabase fetch failed, falling back to local dataset', err);
      }
    }

    // Local Storage / Built-in dataset fallback
    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_SCHEMES_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // Fall through to initial dataset
    }

    // Default to verified initial dataset
    localStorage.setItem(LOCAL_STORAGE_SCHEMES_KEY, JSON.stringify(INITIAL_SCHEMES));
    return INITIAL_SCHEMES;
  }

  /**
   * Get single scheme by ID or Slug
   */
  static async getSchemeById(idOrSlug: string): Promise<Scheme | null> {
    const schemes = await this.getAllSchemes();
    return schemes.find((s) => s.id === idOrSlug || s.slug === idOrSlug) || null;
  }

  /**
   * Add new scheme (Admin function)
   */
  static async addScheme(newScheme: Omit<Scheme, 'id' | 'created_at' | 'updated_at'>): Promise<Scheme> {
    const schemeToAdd: Scheme = {
      ...newScheme,
      id: `sch-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      slug: newScheme.slug || newScheme.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')
    };

    if (isSupabaseConfigured && supabase) {
      try {
        const { data, error } = await supabase.from('schemes').insert([schemeToAdd]).select().single();
        if (!error && data) {
          return data as Scheme;
        }
      } catch (err) {
        console.warn('Supabase insert failed, saving locally', err);
      }
    }

    // Local update
    const schemes = await this.getAllSchemes();
    const updated = [schemeToAdd, ...schemes];
    localStorage.setItem(LOCAL_STORAGE_SCHEMES_KEY, JSON.stringify(updated));
    return schemeToAdd;
  }

  static async createScheme(newScheme: Omit<Scheme, 'id' | 'created_at' | 'updated_at'>): Promise<Scheme> {
    return this.addScheme(newScheme);
  }

  /**
   * Update existing scheme (Admin function)
   */
  static async updateScheme(id: string, updates: Partial<Scheme>): Promise<Scheme> {
    const schemes = await this.getAllSchemes();
    const index = schemes.findIndex((s) => s.id === id);
    if (index === -1) {
      throw new Error(`Scheme with id ${id} not found.`);
    }

    const updatedScheme: Scheme = {
      ...schemes[index],
      ...updates,
      updated_at: new Date().toISOString()
    };

    if (isSupabaseConfigured && supabase) {
      try {
        await supabase.from('schemes').update(updates).eq('id', id);
      } catch (err) {
        console.warn('Supabase update failed, saving locally', err);
      }
    }

    schemes[index] = updatedScheme;
    localStorage.setItem(LOCAL_STORAGE_SCHEMES_KEY, JSON.stringify(schemes));
    return updatedScheme;
  }

  /**
   * Update verification status & timestamp (Admin feature)
   */
  static async updateVerificationStatus(
    id: string,
    status: VerificationStatus,
    officialUrl?: string,
    sourceUrl?: string
  ): Promise<Scheme> {
    return this.updateScheme(id, {
      verification_status: status,
      last_verified: new Date().toISOString().split('T')[0],
      ...(officialUrl ? { official_url: officialUrl } : {}),
      ...(sourceUrl ? { source_url: sourceUrl } : {})
    });
  }

  /**
   * Delete scheme
   */
  static async deleteScheme(id: string): Promise<boolean> {
    if (isSupabaseConfigured && supabase) {
      try {
        await supabase.from('schemes').delete().eq('id', id);
      } catch (err) {
        console.warn('Supabase delete failed', err);
      }
    }

    const schemes = await this.getAllSchemes();
    const filtered = schemes.filter((s) => s.id !== id);
    localStorage.setItem(LOCAL_STORAGE_SCHEMES_KEY, JSON.stringify(filtered));
    return true;
  }

  /**
   * Reset to verified default dataset
   */
  static resetToDefault(): Scheme[] {
    localStorage.setItem(LOCAL_STORAGE_SCHEMES_KEY, JSON.stringify(INITIAL_SCHEMES));
    return INITIAL_SCHEMES;
  }

  static resetToDefaults(): Scheme[] {
    return this.resetToDefault();
  }

  // --- Saved Schemes & Reminders ---

  static getSavedSchemes(): SavedScheme[] {
    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_SAVED_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  static saveScheme(schemeId: string, scheme?: Scheme, reminderDate?: string, reminderNote?: string): SavedScheme[] {
    const current = this.getSavedSchemes();
    const exists = current.find((s) => s.scheme_id === schemeId);

    if (exists) {
      // Update existing reminder if provided
      const updated = current.map((s) =>
        s.scheme_id === schemeId
          ? { ...s, reminder_date: reminderDate ?? s.reminder_date, reminder_note: reminderNote ?? s.reminder_note }
          : s
      );
      localStorage.setItem(LOCAL_STORAGE_SAVED_KEY, JSON.stringify(updated));
      return updated;
    }

    const newSaved: SavedScheme = {
      id: `saved-${Date.now()}`,
      scheme_id: schemeId,
      scheme,
      created_at: new Date().toISOString(),
      reminder_date: reminderDate,
      reminder_note: reminderNote,
      reminder_completed: false
    };

    const updated = [newSaved, ...current];
    localStorage.setItem(LOCAL_STORAGE_SAVED_KEY, JSON.stringify(updated));
    return updated;
  }

  static removeSavedScheme(schemeId: string): SavedScheme[] {
    const current = this.getSavedSchemes();
    const updated = current.filter((s) => s.scheme_id !== schemeId);
    localStorage.setItem(LOCAL_STORAGE_SAVED_KEY, JSON.stringify(updated));
    return updated;
  }

  static toggleReminderCompleted(savedId: string): SavedScheme[] {
    const current = this.getSavedSchemes();
    const updated = current.map((s) =>
      s.id === savedId ? { ...s, reminder_completed: !s.reminder_completed } : s
    );
    localStorage.setItem(LOCAL_STORAGE_SAVED_KEY, JSON.stringify(updated));
    return updated;
  }
}
