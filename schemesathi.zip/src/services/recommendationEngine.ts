import { Scheme, SchemeMatchResult, MatchReason, MatchTier } from '../types/scheme';
import { QuestionnaireAnswers, IncomeBracket } from '../types/questionnaire';

/**
 * Numeric upper limits for income brackets in INR for comparison
 */
const INCOME_LIMIT_MAP: Record<IncomeBracket, number> = {
  bpl_antyodaya: 75000,
  below_1_lakh: 100000,
  '1_to_2_5_lakh': 250000,
  '2_5_to_5_lakh': 500000,
  '5_to_8_lakh': 800000,
  above_8_lakh: 2000000
};

/**
 * Pure rule-based recommendation engine for SchemeSathi.
 * Does NOT use an opaque AI model to decide eligibility.
 * Compares user answers against verified criteria and outputs transparent score breakdown.
 */
export function evaluateSchemeEligibility(
  scheme: Scheme,
  answers: QuestionnaireAnswers
): SchemeMatchResult {
  const reasons: MatchReason[] = [];
  let totalScore = 0;
  let maxPossibleScore = 0;
  let hardDisqualified = false;

  // 1. State / Geographic Relevance (Weight: 30)
  const isAllIndia = scheme.state.toLowerCase() === 'all india';
  const isStateMatch = isAllIndia || (answers.state && scheme.state.toLowerCase() === answers.state.toLowerCase());
  maxPossibleScore += 30;

  if (isStateMatch) {
    totalScore += 30;
    reasons.push({
      matched: true,
      criterion: 'Geographic Coverage',
      description: isAllIndia
        ? 'Valid across all States and Union Territories in India'
        : `Specifically available in your state of ${answers.state}`,
      weight: 30
    });
  } else {
    // If state does not match at all (e.g. Assam scheme for Bihar resident), heavily deprioritize
    reasons.push({
      matched: false,
      criterion: 'State Mismatch',
      description: `This scheme is exclusive to ${scheme.state}, whereas you selected ${answers.state}`,
      weight: 0
    });
    hardDisqualified = true;
  }

  // 2. Occupation & Target Group (Weight: 25)
  maxPossibleScore += 25;
  if (!scheme.occupations || scheme.occupations.length === 0 || scheme.occupations.includes('all')) {
    totalScore += 20; // Broad eligibility
    reasons.push({
      matched: true,
      criterion: 'Open Occupation',
      description: 'Open to citizens across all occupations and employment categories',
      weight: 20
    });
  } else if (answers.occupation && scheme.occupations.includes(answers.occupation)) {
    totalScore += 25;
    reasons.push({
      matched: true,
      criterion: 'Occupation Match',
      description: `Directly tailored for ${answers.occupation.replace(/_/g, ' ')}s`,
      weight: 25
    });
  } else {
    // For specialized schemes (e.g. farmer scheme for a student)
    if (scheme.farmer_requirement && answers.occupation !== 'farmer') {
      reasons.push({
        matched: false,
        criterion: 'Farmer Status',
        description: 'Requires agricultural landholding / active farmer status',
        weight: 0
      });
      hardDisqualified = true;
    } else if (scheme.student_requirement && answers.occupation !== 'student') {
      reasons.push({
        matched: false,
        criterion: 'Student Status',
        description: 'Requires active enrollment as a student in a recognized institution',
        weight: 0
      });
      hardDisqualified = true;
    }
  }

  // 3. Gender Requirement (Weight: 15)
  if (scheme.gender_eligibility && scheme.gender_eligibility !== 'all') {
    maxPossibleScore += 15;
    if (scheme.gender_eligibility === 'female_only') {
      if (answers.gender === 'female') {
        totalScore += 15;
        reasons.push({
          matched: true,
          criterion: 'Target Group (Women)',
          description: 'Designed specifically for women / female beneficiaries',
          weight: 15
        });
      } else {
        reasons.push({
          matched: false,
          criterion: 'Target Group Mismatch',
          description: 'This scheme is specifically for women beneficiaries',
          weight: 0
        });
        hardDisqualified = true;
      }
    }
  }

  // 4. Income Limit & Financial Category (Weight: 20)
  maxPossibleScore += 20;
  const userIncomeValue = answers.incomeBracket ? INCOME_LIMIT_MAP[answers.incomeBracket] : 150000;

  if (scheme.income_category === 'bpl_antyodaya') {
    if (answers.hasBplOrRationCard || answers.incomeBracket === 'bpl_antyodaya') {
      totalScore += 20;
      reasons.push({
        matched: true,
        criterion: 'BPL / Economic Criteria',
        description: 'Matches priority economic threshold (BPL / Antyodaya category)',
        weight: 20
      });
    } else {
      reasons.push({
        matched: false,
        criterion: 'Income Threshold',
        description: 'Primarily intended for BPL / low-income households',
        weight: 5
      });
    }
  } else if (scheme.income_limit) {
    if (userIncomeValue <= scheme.income_limit) {
      totalScore += 20;
      reasons.push({
        matched: true,
        criterion: 'Income Eligibility',
        description: `Your reported income range is within the scheme limit of ₹${scheme.income_limit.toLocaleString('en-IN')}/year`,
        weight: 20
      });
    } else {
      reasons.push({
        matched: false,
        criterion: 'Income Limit Exceeded',
        description: `Scheme requires family income under ₹${scheme.income_limit.toLocaleString('en-IN')}/year`,
        weight: 0
      });
    }
  } else {
    totalScore += 15;
    reasons.push({
      matched: true,
      criterion: 'Universal Income Access',
      description: 'No strict upper income ceiling specified in official criteria',
      weight: 15
    });
  }

  // 5. Age Range (Weight: 15)
  if (scheme.min_age !== undefined || scheme.max_age !== undefined) {
    maxPossibleScore += 15;
    const userAge = answers.age || 25;
    const minAge = scheme.min_age ?? 0;
    const maxAge = scheme.max_age ?? 120;

    if (userAge >= minAge && userAge <= maxAge) {
      totalScore += 15;
      reasons.push({
        matched: true,
        criterion: 'Age Criteria',
        description: `Your age (${userAge}) is within the eligible range of ${minAge} to ${maxAge === 120 ? 'above' : maxAge} years`,
        weight: 15
      });
    } else {
      reasons.push({
        matched: false,
        criterion: 'Age Criteria Not Met',
        description: `Requires age between ${minAge} and ${maxAge} years (Your age: ${userAge})`,
        weight: 0
      });
      // For old-age schemes or youth-specific schemes, this is a disqualifier
      if (minAge >= 55 || maxAge <= 30) {
        hardDisqualified = true;
      }
    }
  }

  // 6. Disability Specific Criteria (Weight: 15)
  if (scheme.disability_requirement) {
    maxPossibleScore += 15;
    if (answers.hasDisability) {
      totalScore += 15;
      reasons.push({
        matched: true,
        criterion: 'Divyangjan / Disability Support',
        description: 'Tailored for persons with disabilities (Divyangjan support)',
        weight: 15
      });
    } else {
      reasons.push({
        matched: false,
        criterion: 'Disability Requirement',
        description: 'Requires valid Unique Disability ID (UDID) or certified disability',
        weight: 0
      });
      hardDisqualified = true;
    }
  }

  // 7. Area Type (Rural / Urban) (Weight: 10)
  if (scheme.area_type && scheme.area_type !== 'all') {
    maxPossibleScore += 10;
    if (answers.areaType === scheme.area_type || !answers.areaType) {
      totalScore += 10;
      reasons.push({
        matched: true,
        criterion: 'Habitat / Location Type',
        description: `Matches your ${scheme.area_type} location profile`,
        weight: 10
      });
    }
  }

  // 8. Social Category (SC/ST/OBC) (Weight: 10)
  if (scheme.caste_category && !scheme.caste_category.includes('all')) {
    maxPossibleScore += 10;
    if (answers.socialCategory && scheme.caste_category.includes(answers.socialCategory as any)) {
      totalScore += 10;
      reasons.push({
        matched: true,
        criterion: 'Category Reservation / Priority',
        description: `Covers ${answers.socialCategory.toUpperCase()} beneficiary category`,
        weight: 10
      });
    }
  }

  // Calculate final normalized percentage
  const percentage = maxPossibleScore > 0 ? Math.round((totalScore / maxPossibleScore) * 100) : 50;

  // Determine Match Tier
  let tier: MatchTier = 'general';
  if (!hardDisqualified && percentage >= 75) {
    tier = 'strong';
  } else if (!hardDisqualified && percentage >= 45) {
    tier = 'possible';
  } else {
    tier = 'general';
  }

  return {
    scheme,
    matchScore: hardDisqualified ? Math.min(percentage, 30) : percentage,
    tier,
    reasons,
    isEligibleCandidate: !hardDisqualified && percentage >= 45
  };
}

/**
 * Evaluate all schemes against user answers and sort by match score
 */
export function rankSchemes(
  schemes: Scheme[],
  answers: QuestionnaireAnswers
): SchemeMatchResult[] {
  const results = schemes.map((scheme) => evaluateSchemeEligibility(scheme, answers));

  return results.sort((a, b) => {
    // Sort strong first, then possible, then general, then by score descending
    const tierPriority: Record<MatchTier, number> = {
      strong: 3,
      possible: 2,
      general: 1
    };

    if (tierPriority[a.tier] !== tierPriority[b.tier]) {
      return tierPriority[b.tier] - tierPriority[a.tier];
    }
    return b.matchScore - a.matchScore;
  });
}

export const rankSchemesByEligibility = rankSchemes;
