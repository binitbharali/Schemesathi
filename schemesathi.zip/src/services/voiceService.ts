/**
 * Browser Speech Recognition & Audio Synthesis Service
 * Provides Voice-Search & Accessibility Audio Narration
 */

// Extend window interface for WebkitSpeechRecognition
declare global {
  interface Window {
    webkitSpeechRecognition?: any;
    SpeechRecognition?: any;
  }
}

export class VoiceService {
  /**
   * Check if speech recognition is available in the user's browser
   */
  static isSpeechRecognitionSupported(): boolean {
    return typeof window !== 'undefined' && Boolean(window.SpeechRecognition || window.webkitSpeechRecognition);
  }

  /**
   * Check if text-to-speech synthesis is available
   */
  static isSpeechSynthesisSupported(): boolean {
    return typeof window !== 'undefined' && 'speechSynthesis' in window;
  }

  /**
   * Start listening for voice input
   */
  static startListening(
    lang: string,
    onResult: (transcript: string) => void,
    onError: (err: string) => void,
    onEnd: () => void
  ): { stop: () => void } | null {
    if (!this.isSpeechRecognitionSupported()) {
      onError('Speech recognition is not supported in this browser.');
      return null;
    }

    try {
      const SpeechRecognitionClass = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognitionClass();

      // Set language (e.g., 'hi-IN', 'en-IN', 'as-IN')
      let recognitionLang = 'en-IN';
      if (lang === 'hi') recognitionLang = 'hi-IN';
      else if (lang === 'as') recognitionLang = 'as-IN';
      recognition.lang = recognitionLang;

      recognition.continuous = false;
      recognition.interimResults = true;

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        if (transcript.trim()) {
          onResult(transcript);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        onError(event.error === 'not-allowed' ? 'Microphone permission denied.' : 'Voice recognition failed. Please try typing.');
      };

      recognition.onend = () => {
        onEnd();
      };

      recognition.start();

      return {
        stop: () => {
          try {
            recognition.stop();
          } catch {
            // ignore
          }
        }
      };
    } catch (e: any) {
      onError(e?.message || 'Failed to initialize voice recognition');
      return null;
    }
  }

  /**
   * Read text aloud using SpeechSynthesis (Accessibility / Simple Mode helper)
   */
  static speak(text: string, lang: string = 'en'): void {
    if (!this.isSpeechSynthesisSupported()) return;

    try {
      window.speechSynthesis.cancel(); // stop previous speech
      const cleanText = text.replace(/[*_#]/g, '').trim();
      if (!cleanText) return;

      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.rate = 0.95; // slightly slower for better comprehension
      utterance.pitch = 1.0;

      let speechLang = 'en-IN';
      if (lang === 'hi') speechLang = 'hi-IN';
      else if (lang === 'as') speechLang = 'hi-IN'; // fallback for Assamese TTS if not natively available in browser
      utterance.lang = speechLang;

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('Speech synthesis error', e);
    }
  }

  /**
   * Stop any active speech readout
   */
  static stopSpeaking(): void {
    if (this.isSpeechSynthesisSupported()) {
      window.speechSynthesis.cancel();
    }
  }
}
