import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { AppUser, UserRole } from '../types/user';
import { supabase, isSupabaseConfigured } from '../services/supabase';

interface AuthContextType {
  user: AppUser | null;
  isAdmin: boolean;
  loginAsCitizen: (email?: string, name?: string) => void;
  loginAsAdmin: (password?: string) => boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const LOCAL_STORAGE_USER_KEY = 'schemesathi_current_user';

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AppUser | null>(() => {
    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_USER_KEY);
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    if (isSupabaseConfigured && supabase) {
      supabase.auth.getSession().then(({ data: { session } }) => {
        if (session?.user) {
          const appUser: AppUser = {
            id: session.user.id,
            email: session.user.email || '',
            role: session.user.email?.includes('admin') ? 'admin' : 'citizen',
            displayName: session.user.user_metadata?.full_name || session.user.email?.split('@')[0],
            createdAt: session.user.created_at
          };
          setUser(appUser);
        }
      });

      const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
        if (session?.user) {
          const appUser: AppUser = {
            id: session.user.id,
            email: session.user.email || '',
            role: session.user.email?.includes('admin') ? 'admin' : 'citizen',
            displayName: session.user.user_metadata?.full_name || session.user.email?.split('@')[0],
            createdAt: session.user.created_at
          };
          setUser(appUser);
          localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(appUser));
        } else {
          setUser(null);
          localStorage.removeItem(LOCAL_STORAGE_USER_KEY);
        }
      });

      return () => subscription.unsubscribe();
    }
  }, []);

  const loginAsCitizen = (email: string = 'citizen@schemesathi.in', name: string = 'Citizen User') => {
    const newUser: AppUser = {
      id: `user-${Date.now()}`,
      email,
      role: 'citizen',
      displayName: name,
      createdAt: new Date().toISOString()
    };
    setUser(newUser);
    localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(newUser));
  };

  const loginAsAdmin = (pass: string = 'admin123'): boolean => {
    // Demo admin authorization pass
    const adminUser: AppUser = {
      id: 'admin-sih-evaluator',
      email: 'admin@gov.in',
      role: 'admin',
      displayName: 'SIH Department Admin (Nodal Officer)',
      createdAt: new Date().toISOString()
    };
    setUser(adminUser);
    localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(adminUser));
    return true;
  };

  const logout = () => {
    if (isSupabaseConfigured && supabase) {
      supabase.auth.signOut();
    }
    setUser(null);
    localStorage.removeItem(LOCAL_STORAGE_USER_KEY);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAdmin: user?.role === 'admin',
        loginAsCitizen,
        loginAsAdmin,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
