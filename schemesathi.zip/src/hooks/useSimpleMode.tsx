import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { AnalyticsService } from '../services/analyticsService';

interface SimpleModeContextType {
  isSimpleMode: boolean;
  toggleSimpleMode: () => void;
  setSimpleMode: (enabled: boolean) => void;
}

const SimpleModeContext = createContext<SimpleModeContextType | undefined>(undefined);

const LOCAL_STORAGE_SIMPLE_MODE_KEY = 'schemesathi_simple_mode';

export const SimpleModeProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isSimpleMode, setIsSimpleModeState] = useState<boolean>(() => {
    try {
      return localStorage.getItem(LOCAL_STORAGE_SIMPLE_MODE_KEY) === 'true';
    } catch {
      return false;
    }
  });

  const setSimpleMode = (enabled: boolean) => {
    setIsSimpleModeState(enabled);
    try {
      localStorage.setItem(LOCAL_STORAGE_SIMPLE_MODE_KEY, String(enabled));
      AnalyticsService.logEvent('simple_mode_toggled', { enabled });
    } catch {
      // ignore
    }
  };

  const toggleSimpleMode = () => {
    setSimpleMode(!isSimpleMode);
  };

  return (
    <SimpleModeContext.Provider value={{ isSimpleMode, toggleSimpleMode, setSimpleMode }}>
      {children}
    </SimpleModeContext.Provider>
  );
};

export const useSimpleMode = (): SimpleModeContextType => {
  const context = useContext(SimpleModeContext);
  if (!context) {
    throw new Error('useSimpleMode must be used within a SimpleModeProvider');
  }
  return context;
};
