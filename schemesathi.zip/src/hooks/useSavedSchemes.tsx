import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { SavedScheme, Scheme } from '../types/scheme';
import { SchemeService } from '../services/schemeService';
import { AnalyticsService } from '../services/analyticsService';

interface SavedSchemesContextType {
  savedSchemes: SavedScheme[];
  isSaved: (schemeId: string) => boolean;
  saveScheme: (scheme: Scheme, reminderDate?: string, reminderNote?: string) => void;
  removeSavedScheme: (schemeId: string) => void;
  toggleReminder: (savedId: string) => void;
  toggleReminderCompleted: (schemeId: string) => void;
  updateReminder: (schemeId: string, reminderDate: string, reminderNote: string) => void;
}

const SavedSchemesContext = createContext<SavedSchemesContextType | undefined>(undefined);

export const SavedSchemesProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [savedSchemes, setSavedSchemes] = useState<SavedScheme[]>([]);

  useEffect(() => {
    setSavedSchemes(SchemeService.getSavedSchemes());
  }, []);

  const isSaved = (schemeId: string) => {
    return savedSchemes.some((s) => s.scheme_id === schemeId);
  };

  const saveScheme = (scheme: Scheme, reminderDate?: string, reminderNote?: string) => {
    const updated = SchemeService.saveScheme(scheme.id, scheme, reminderDate, reminderNote);
    setSavedSchemes(updated);
    AnalyticsService.logEvent('scheme_saved', { schemeId: scheme.id, schemeName: scheme.name });
  };

  const removeSavedScheme = (schemeId: string) => {
    const updated = SchemeService.removeSavedScheme(schemeId);
    setSavedSchemes(updated);
  };

  const toggleReminder = (savedId: string) => {
    const updated = SchemeService.toggleReminderCompleted(savedId);
    setSavedSchemes(updated);
  };

  const toggleReminderCompleted = (schemeId: string) => {
    const saved = savedSchemes.find((s) => s.scheme_id === schemeId || s.id === schemeId);
    if (saved) {
      toggleReminder(saved.id);
    }
  };

  const updateReminder = (schemeId: string, reminderDate: string, reminderNote: string) => {
    const scheme = savedSchemes.find((s) => s.scheme_id === schemeId)?.scheme;
    const updated = SchemeService.saveScheme(schemeId, scheme, reminderDate, reminderNote);
    setSavedSchemes(updated);
  };

  return (
    <SavedSchemesContext.Provider
      value={{
        savedSchemes,
        isSaved,
        saveScheme,
        removeSavedScheme,
        toggleReminder,
        toggleReminderCompleted,
        updateReminder
      }}
    >
      {children}
    </SavedSchemesContext.Provider>
  );
};

export const useSavedSchemes = (): SavedSchemesContextType => {
  const context = useContext(SavedSchemesContext);
  if (!context) {
    throw new Error('useSavedSchemes must be used within a SavedSchemesProvider');
  }
  return context;
};
