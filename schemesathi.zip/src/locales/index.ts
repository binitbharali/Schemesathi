import { en } from './en';
import { hi } from './hi';
import { as } from './as';

export type LanguageCode = 'en' | 'hi' | 'as';

export const translations = {
  en,
  hi,
  as
};

export const SUPPORTED_LANGUAGES: { code: LanguageCode; label: string; nativeName: string }[] = [
  { code: 'en', label: 'English', nativeName: 'English' },
  { code: 'hi', label: 'Hindi', nativeName: 'हिंदी' },
  { code: 'as', label: 'Assamese', nativeName: 'অসমীয়া' }
];
