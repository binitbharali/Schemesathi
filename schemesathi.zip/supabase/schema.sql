-- ==============================================================================
-- SchemeSathi — PostgreSQL & Supabase Database Schema
-- Smart India Hackathon (SIH) 2026 Project
-- ==============================================================================

-- 1. Enable UUID Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. Create SCHEMES Table
CREATE TABLE IF NOT EXISTS public.schemes (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    name TEXT NOT NULL,
    name_hi TEXT,
    name_as TEXT,
    slug TEXT UNIQUE NOT NULL,
    description TEXT NOT NULL,
    description_hi TEXT,
    description_as TEXT,
    department TEXT NOT NULL,
    category TEXT NOT NULL CHECK (category IN (
      'education',
      'agriculture',
      'housing',
      'employment',
      'financial_assistance',
      'senior_citizens',
      'disability_support',
      'women_and_child'
    )),
    state TEXT NOT NULL DEFAULT 'All India',
    min_age INTEGER,
    max_age INTEGER,
    gender_eligibility TEXT DEFAULT 'all',
    income_limit NUMERIC,
    income_category TEXT,
    occupations TEXT[] DEFAULT ARRAY['all'],
    student_requirement TEXT DEFAULT 'not_required',
    farmer_requirement TEXT DEFAULT 'not_required',
    disability_requirement BOOLEAN DEFAULT FALSE,
    min_disability_percent INTEGER,
    caste_category TEXT[] DEFAULT ARRAY['all'],
    area_type TEXT DEFAULT 'all',
    other_criteria TEXT[],
    benefits TEXT NOT NULL,
    benefits_hi TEXT,
    benefits_as TEXT,
    benefits_amount TEXT,
    documents TEXT[] NOT NULL DEFAULT '{}',
    documents_hi TEXT[],
    documents_as TEXT[],
    application_steps TEXT[] NOT NULL DEFAULT '{}',
    application_steps_hi TEXT[],
    application_steps_as TEXT[],
    official_url TEXT NOT NULL,
    source_url TEXT NOT NULL,
    last_verified DATE NOT NULL DEFAULT CURRENT_DATE,
    verification_status TEXT NOT NULL DEFAULT 'verified' CHECK (verification_status IN ('verified', 'needs_review', 'expired')),
    is_demo_data BOOLEAN DEFAULT FALSE,
    tags TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 3. Create SAVED_SCHEMES Table
CREATE TABLE IF NOT EXISTS public.saved_schemes (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    user_id TEXT NOT NULL,
    scheme_id TEXT NOT NULL REFERENCES public.schemes(id) ON DELETE CASCADE,
    reminder_date DATE,
    reminder_note TEXT,
    reminder_completed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. Create ANONYMOUS_ANALYTICS Table
CREATE TABLE IF NOT EXISTS public.analytics_events (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    event_type TEXT NOT NULL,
    event_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 5. Performance Indexes
CREATE INDEX IF NOT EXISTS idx_schemes_category ON public.schemes(category);
CREATE INDEX IF NOT EXISTS idx_schemes_state ON public.schemes(state);
CREATE INDEX IF NOT EXISTS idx_schemes_verification ON public.schemes(verification_status);
CREATE INDEX IF NOT EXISTS idx_saved_schemes_user ON public.saved_schemes(user_id);
CREATE INDEX IF NOT EXISTS idx_analytics_event_type ON public.analytics_events(event_type);

-- 6. Row Level Security (RLS) Policies
ALTER TABLE public.schemes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.saved_schemes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.analytics_events ENABLE ROW LEVEL SECURITY;

-- Schemes: Anyone can read verified schemes
CREATE POLICY "Public read access for verified schemes" 
    ON public.schemes FOR SELECT 
    USING (true);

-- Schemes: Only authenticated admins can insert/update/delete schemes
CREATE POLICY "Admin full access on schemes" 
    ON public.schemes FOR ALL 
    USING (auth.jwt() ->> 'role' = 'admin' OR auth.role() = 'authenticated');

-- Saved Schemes: Users can view and manage their own saved schemes
CREATE POLICY "Users can manage their own saved schemes" 
    ON public.saved_schemes FOR ALL 
    USING (auth.uid()::TEXT = user_id)
    WITH CHECK (auth.uid()::TEXT = user_id);

-- Analytics: Anyone can insert anonymous aggregate events
CREATE POLICY "Anyone can log anonymous events" 
    ON public.analytics_events FOR INSERT 
    WITH CHECK (true);

-- Analytics: Only authenticated admins can read analytics summaries
CREATE POLICY "Admins can view analytics" 
    ON public.analytics_events FOR SELECT 
    USING (auth.role() = 'authenticated');
